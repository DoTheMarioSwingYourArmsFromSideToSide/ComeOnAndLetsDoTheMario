(function ($) {
	$.extend(mrm.cmp, {
		promoApp : {
			init : function () {
				var that = this;
				
				Cufon.replace(".p9", {			  
					fontSize: '40px',
					color: '#788BA4',
					fontFamily: 'Klavika CH Medium Condensed'
				});
				
				$('#helpCenterRequestForm').bind('submit', function(e) {
					if ( that.formValidator() ) {
						var FirstName = $_('#FirstName').val();
			            var fName = "";
			            var firstChar = FirstName.substring(0,1).toUpperCase();
			            var theRest = FirstName.substring(1,FirstName.length).toLowerCase();
			            fName = firstChar + theRest;
			            
			            $_('#FirstName').val(fName);
			            
			            e.target.submit();
					} else {
						e.preventDefault();
					}
				});
				
				$('#signup .exitBtn a').bind('click', function () {
					that.hideSignUp();
				});
			},
		
			f : function (elem, helperMsg) {
				if (elem.value.length == 0) {
					alert(helperMsg);
					elem.focus(); 
					return false;
				}
				return true;
			},
			
			isEmpty : function (elem, defaultValue, helperMsg) {
				var val = $.trim(elem.value);
				
				if (val.length == 0 || val.toLowerCase() === defaultValue.toLowerCase()) {
					alert (helperMsg);
					elem.focus();
					return false;
				} else {
					return true
				}
			},

			isAlphabet : function (elem, helperMsg) {
				var alphaExp = /^[a-zA-Z\s\a-zA-Z]+$/;
				
				if (elem.value.match(alphaExp)) {
					return true;
				} else {
					alert (helperMsg);
					elem.focus();
					return false;
				}
			},

			isAlphanumeric : function (elem, helperMsg) {
				var alphaExp = /^[0-9\s\a-zA-Z]+$/;
				
				if (elem.value.match(alphaExp)) {
					return true;
				} else {
					alert(helperMsg);
					elem.focus();
					return false;
				}
			},

			madeSelection : function (elem, helperMsg) {
				var sList = /^(AK|AL|AR|AZ|CA|CO|CT|DC|DE|FL|GA|HI|IA|ID|IL|IN|KS|KY|LA|MA|MD|ME|MI|MN|MO|MS|MT|NB|NC|ND|NH|NJ|NM|NV|NY|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VA|VT|WA|WI|WV|WY)$/i;
				
				if (elem.value.match(sList)) {
					return true;
				} else {
					alert(helperMsg);
					elem.focus();
					return false;
				}
			},

			emailValidator : function (elem, helperMsg) {
				var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-Z0-9]{2,4}$/;
				
				if (elem.value.match(emailExp)) {
					return true;
				} else {
					alert(helperMsg);
					elem.focus();
					return false;
				}
			},

			emailValidatorB : function (elem, helperMsg) {
				var one = document.helpCenterRequestForm.Email.value,
					another = document.helpCenterRequestForm.EmailConfirm.value;
				
				if (one.toLowerCase() == another.toLowerCase()) {
					return true;
				} else {
					alert(helperMsg);
					elem.focus();
					return false;
				}
			},

			isNumeric : function (elem, helperMsg) {
				var ZipCode = /^\d{5}([\-]\d{4})?$/;
				
				if (elem.value.match(ZipCode)) {
					return true;
				} else {
					alert(helperMsg);
					elem.focus();
					return false;
				}
			},
			
			showSignUp : function () {
				$('.promoApp #signup').delay(400).fadeIn(500);
				$('.promoApp').fadeIn(500);
				$('#all .active').removeClass('active');
				$('#all .tsignup a').addClass('active');
			},

			hideSignUp : function () {
				$('.promoApp #signup').fadeOut(600);
				$('.promoApp').delay(600).fadeOut(600);
			},

				/* Form Validator
				--------------------------------------------------------------------*/
			formValidator : function () {
				var FirstName = document.getElementById('FirstName'),
					LastName = document.getElementById('LastName'),
					Email = document.getElementById('Email'),
					EmailConfirm = document.getElementById('EmailConfirm'),
					Address = document.getElementById('Address'),
					City = document.getElementById('City'),
					Zip = document.getElementById('Zip'),
					State = document.getElementById('State');

				if ((null == FirstName) || this.isEmpty(FirstName, 'first name*', "Please enter your first name")) {
					if ((null == LastName) || this.isEmpty(LastName, 'last name*', "Please enter your last name")) {
						if ((null == Email) || this.emailValidator(Email, "Please enter a valid email address")) {
							if ((null == EmailConfirm) || this.emailValidatorB(EmailConfirm, "Email does not match")) {
								if ((null == Zip) || this.isNumeric(Zip, "Please enter your 5 digit or 5 digit +4 zip code")) {
									if ((null == State) || this.madeSelection(State, "Please choose a State")) {
										return true;
									}
								}
							}
						}
					}
				}
				
				return false;
			}
		}
	});
}(jQuery));