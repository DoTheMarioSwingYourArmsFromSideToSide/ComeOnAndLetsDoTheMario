/**********
	Like Button Usage:
	
	To return a referring property to anchor to page content (eg. http://www.chevy.com/?atag=atag)
	<script>MRMSocial.fbLikeBtn("my_jump_to_tag");</script>
	
	Notes on Like Button: 
	* The domain property can be overridden and made human readable by embedding the following to the liked page: <meta property="og:site_name" content="Chevy" />
	* Parameters can be passed to move to sections within the page http://www.myurl.com/mypage/?anchor=myAnchor
	* Hash tags cause the URL not to be unique, so if there are multiple like buttons on the page, Facebook sees them as all the same.
	* You need to quit the browser inorder for new URLs to be reflected, as Facebook caches the sessions
*/


var appID;
$_(document).ready(function(){
	if (window.location.hostname == "itl.chevrolet.mrmworldwide.com") { // use Chevy - ITL - Facebook AppID
		appID = "184723318221730";
	} else if (window.location.hostname == "itlprj1.gm.mrmworldwide.com") { // use Chevy - ITLProj1 - Facebook AppID
		appID = "116571388414671";
	} else if (window.location.hostname == "origin-chevrolet-preprod-iad.pnangis.gm.com") { // use Chevy - PRE PROD ORIGIN -  Facebook AppID
		appID = "162839723762276";
	} else if (window.location.hostname == "preprod.rs.chevrolet.com") { // use Chevy - PRE PROD - Akamai - Facebook AppID
		appID = "173472359354564";
	} else if (window.location.hostname == "origin-chevrolet-prod-sat.pnangis.gm.com") { // use Chevy - PROD - IAD - Facebook AppID
		appID = "175165699185753";
	} else if (window.location.hostname == "origin-chevrolet-prod-iad.pnangis.gm.com") { // use Chevy - PROD - SAT - Facebook AppID
		appID = "168780946499570";
	} else { // use PROD Facebook AppID
		appID = "140461456010309";
	}
	
	// Make sure that there is an fb-root on page
	var _check = $_('div#fb-root').html();
	if ( (_check == null) || (_check.length < 1) )
		{ $_('body').append('<div id="fb-root"></div>'); }

//	if (document.getElementById('fb-root') == null) {
//		return;
//	}
	
	window.fbAsyncInit = function() {
	//override facebooks strigify for compatibility
    FB.JSON.stringify = function (value) { return JSON.encode(value);};
    
		FB.init({
			appId  : appID,
			app_id : appID,
			api_key: appID,
			status : true, // check login status
			cookie : true, // enable cookies to allow the server to access the session
			xfbml  : true,  // parse XFBML
			channelURL : 'http://www.chevrolet.com/channel.html' // Custom channel URL
		});
		
		FB.Event.subscribe('edge.create', function(href, widget) {
			console.log('You liked ' + href, widget);
		});
	};
	(function() {
		if (document.getElementById('fb-root') != null) {
			var e = document.createElement('script');
			e.src = 'https://connect.facebook.net/en_US/all.js';
			e.async = true;
			document.getElementById('fb-root').appendChild(e);
		}
	}());

});




var MRMSocial = {
	
	fbLikeBtn : function(url) {
		return document.write("<fb:like href=\""+url+"\" layout=\"button_count\" show_faces=\"false\" width=\"90\"></fb:like>");
	},
	
	fbPublish : function(message, aName, aCaption, aDesc, aHREF) {
		if (document.getElementById('fb-root') == null) {
			alert("No 'fb-root' div found in the document - see implementation instructions for Facebook integration");
			return;
		}
		// For the �, � and � - Remove double amp
		aDesc = aDesc.replace(/&amp;reg;/gi, '(r)');
		aDesc = aDesc.replace(/&reg;/gi, '(r)');
		aDesc = aDesc.replace(/&amp;copy;/gi, '(c)');
		aDesc = aDesc.replace(/&amp;copy;/gi, '(c)');
		aDesc = aDesc.replace(/&amp;8482;/gi, '(tm)');
		aDesc = aDesc.replace(/&amp;8482;/gi, '(tm)');

		// For the �, � and � - Remove double amp
		aCaption = aCaption.replace(/&amp;reg;/gi, '(r)');
		aCaption = aCaption.replace(/&reg;/gi, '(r)');
		aCaption = aCaption.replace(/&amp;copy;/gi, '(c)');
		aCaption = aCaption.replace(/&amp;copy;/gi, '(c)');
		aCaption = aCaption.replace(/&amp;8482;/gi, '(tm)');
		aCaption = aCaption.replace(/&amp;8482;/gi, '(tm)');		
		
		console.log("fbPublish: "+aHREF);
		FB.ui({
			method: 'stream.publish',
			app_id: appID,
			api_key: appID,
			message: message,
			attachment: {
				name: aName,
				caption: aCaption,
				description: (
					aDesc
				),
				href: aHREF
			},
			action_links: [{ text: 'Chevy.com', href: "http://www.chevrolet.com" }],
			user_message_prompt: 'Share this with your friends'
		},
		function(response) {
			if (response && response.post_id) {
				//alert('Post was published.');
			} else {
				//alert('Post was not published.');
			}
		});
	},
	
	fbPublishGalleryItem : function(message,name,caption,desc,thumburl,linkurl) {
		if (document.getElementById('fb-root') == null) {
			alert("No 'fb-root' div found in the document - see implementation instructions for Facebook integration");
			return;
		}
		/*linkurl example: http://www.youtube.com/v/VIDEO_ID*/
		tempMedia = (linkurl.indexOf("youtube")>-1)? new Array({'type': 'flash', 'swfsrc': linkurl, 'imgsrc': thumburl, 'width': '80', 'height': '60', 'expanded_width': '400', 'expanded_height': '300'}) : new Array({type: 'image', src: thumburl, href: linkurl});
		//console.log("fbPublishGalleryItem: "+linkurl);
		// For the �, � and � - Remove double amp
		desc = desc.replace(/&amp;reg;/gi, '(r)');
		desc = desc.replace(/&reg;/gi, '(r)');
		desc = desc.replace(/&amp;copy;/gi, '(c)');
		desc = desc.replace(/&amp;copy;/gi, '(c)');
		desc = desc.replace(/&amp;8482;/gi, '(tm)');
		desc = desc.replace(/&amp;8482;/gi, '(tm)');

		// For the �, � and � - Remove double amp
		caption = caption.replace(/&amp;reg;/gi, '(r)');
		caption = caption.replace(/&reg;/gi, '(r)');
		caption = caption.replace(/&amp;copy;/gi, '(c)');
		caption = caption.replace(/&amp;copy;/gi, '(c)');
		caption = caption.replace(/&amp;8482;/gi, '(tm)');
		caption = caption.replace(/&amp;8482;/gi, '(tm)');
		
		FB.ui({
			method: 'stream.publish',
			app_id: appID,
			api_key: appID,
			message: message,
			attachment: {
				name: name,
				caption: caption,
				description: (
					desc
				),
				href: linkurl,
				media: tempMedia
			},
			action_links: [{ text: 'Chevy.com', href: "http://www.chevrolet.com" }],
			user_message_prompt: 'Share this with your friends'
		},
		function(response) {
			if (response && response.post_id) {
				//alert('Post was published.');
			} else {
				//alert('Post was not published.');
			}
		});
	},
	
	fbSimplePublish : function(url) {
		url = MRMSocialUtils.urlEncode(url);
		var fb_post_url = "http://www.facebook.com/share.php?u=" + url;
		window.open (fb_post_url,"newwindow");
	},
        
        fbSimplePublishSized : function(url) {
		url = MRMSocialUtils.urlEncode(url);
		var fb_post_url = "http://www.facebook.com/share.php?u=" + url;
		window.open (fb_post_url,"newwindow","width=600,height=500");
	},
	
	tweet : function(url,text) {
		url = MRMSocialUtils.urlEncode(url);

		// For the �, � and � - Remove double amp
		text = text.replace(/&amp;reg;/gi, '(r)');
		text = text.replace(/&reg;/gi, '(r)');
		text = text.replace(/&amp;copy;/gi, '(c)');
		text = text.replace(/&amp;copy;/gi, '(c)');
		text = text.replace(/&amp;8482;/gi, '(tm)');
		text = text.replace(/&amp;8482;/gi, '(tm)');
		
		// cap twitter text to 120 charaters. URL will require 20
		if (text.length > 120) {
			text = text.substring(0,117);
			text += "...";	
		}
		
		text = MRMSocialUtils.urlEncode(text);
		var tweet_post_url = "http://twitter.com/share?url=" + url + "&text=" + text;
		window.open (tweet_post_url,"newwindow","width=600,height=500");
	},
	
	email : function(subject, message) {
		var email = "";
		subject = escape(subject);
		// Change the Registered symbol to acceptable non-html code
		message = message.replace(/�/gi, '(R)');
		message = message.replace(/&amp;reg;/gi, '(R)');
		message = message.replace(/&reg;/gi, '(R)');

		// Change the Copyright symbol to acceptable non-html code
		message = message.replace(/�/gi, '(c)');
		message = message.replace(/&amp;copy;/gi, '(c)');
		message = message.replace(/&copy;/gi, '(c)');
		
		// Change the Trademark symbol to acceptable non-html code
		message = message.replace(/�/gi, '(tm)');
		message = message.replace(/&8482;/gi, '(tm)');
		message = escape(message);

		var mailto_link = 'mailto:'+email+'?subject='+subject+'&body='+message;
		document.location.href=mailto_link;
	}
};

var MRMSocialUtils = {
	jumpToATag : function(atag) {
		if (atag) {
			var divid = '#'+atag;
			$_(window).scrollTop($_(divid).offset().top);
		}
	},
	
	/*scrollToTag : function(atag) {
		if (atag) {
			// poor performance - to get to work, this plugin must be included in resources - /mds/js/plugins/jquery.scrollTo-min.js
			var tagid = '#'+atag;
			var duration = 1000;
			$_(document).scrollTo( $_(tagid).offset().top, duration );
		}
	},*/
	
	urlVars : function() {
		var vars = [], hash;
		var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
		for(var i = 0; i < hashes.length; i++) {
			hash = hashes[i].split('=');
			vars.push(hash[0]);
			vars[hash[0]] = hash[1];
		}
		return vars;
	},
	
	urlEncode : function( s ) {
		return encodeURIComponent( s ).replace( /\%20/g, '+' ).replace( /!/g, '%21' ).replace( /'/g, '%27' ).replace( /\(/g, '%28' ).replace( /\)/g, '%29' ).replace( /\*/g, '%2A' ).replace( /\~/g, '%7E' );
	},
   
	urlDecode : function( s ) {
		return decodeURIComponent( s.replace( /\+/g, '%20' ).replace( /\%21/g, '!' ).replace( /\%27/g, "'" ).replace( /\%28/g, '(' ).replace( /\%29/g, ')' ).replace( /\%2A/g, '*' ).replace( /\%7E/g, '~' ) );
	}
};