var iTop = 0;
var offset = 0;
var animating = false; 
var delay;
$_(document).ready(function() {
	//iPad only link, visible only when user is on an iPad
	var _IPADCHECK_ = /ipad/gi;
	var _ISIPAD_ =  0;

	// Check for Apple IOS device
	if (_IPADCHECK_.test(navigator.userAgent))  { _ISIPAD_ = 1; }
	
	if(_ISIPAD_ == 1)
	{
		$_('#gMdsFooter div ul li#MobileSite').css('display', 'block');
		
		$_('#gMdsFooter div ul li#MobileSite a#MobileSite').bind('click touchend', function() 
		{
			var _section = 'UNKNOWN '+ irise + ' ';
			switch (parseInt(irise))
			{
				case 4: 	_section = 'HOMEPAGE'; 						break;
				case 13: 	_section = 'FAMILY VEHICLES'; 		break;
				case 21: 	
				case 14: 	_section = 'MODEL HOMEPAGE';			break;
				case 23: 	
				case 15: 	_section = 'GALLERY'; 						break;
				case 17: 	_section = 'SPECS'; 							break;
				case 26:
				case 94: 	_section = 'COMPARISON'; 					break;
				case 46:
				case 47: 	_section = 'OWNERS'; 							break;
				case 52: 	
				case 53: 	_section = 'DEALOC'; 							break;
				case 55: 	
				case 56: 	_section = 'VEHLOC'; 							break;
				case 59:
				case 60: 	_section = 'RAQ'; 								break;
				case 75: 	_section = 'BYO'; 								break;
				case 102:	_section = 'OFFERS'; 							break;
				case 174:	_section = 'INT MODEL HOMEPAGE'; 	break;
				case 250: 
				case 252: _section = 'BRAND EXPERIENCE'; 		break;
			}

			s.manageVars("clearVars","prop40,prop41,prop44,prop45,prop54,prop57,prop58",1);
			s.pev2 = 'FOOTER | VIEW MOBILE SITE'
			mrm.cmp.omniture.trackChevyHF({ siteSection: _section, selection: 'FOOTER', subSelection: 'VIEW MOBILE SITE', activeState: 'INDEX'});

		});
	}

	// Global Footer Omniture Click Events
	$_("div#gMdsFooter div.hook div ul li a").live("click",function()
	{
		var _clickedlink = $_(this).children('span').text().toUpperCase();
		var _section = 'UNKNOWN '+ irise + ' ';
		switch (parseInt(irise))
		{
			case 4: 	_section = 'HOMEPAGE'; 						break;
			case 13: 	_section = 'FAMILY VEHICLES'; 		break;
			case 21: 	
			case 14: 	_section = 'MODEL HOMEPAGE';			break;
			case 23: 	
			case 15: 	_section = 'GALLERY'; 						break;
			case 17: 	_section = 'SPECS'; 							break;
			case 26:
			case 94: 	_section = 'COMPARISON'; 					break;
			case 46:
			case 47: 	_section = 'OWNERS'; 							break;
			case 52: 	
			case 53: 	_section = 'DEALOC'; 							break;
			case 55: 	
			case 56: 	_section = 'VEHLOC'; 							break;
			case 59:
			case 60: 	_section = 'RAQ'; 								break;
			case 75: 	_section = 'BYO'; 								break;
			case 102:	_section = 'OFFERS'; 							break;
			case 174:	_section = 'INT MODEL HOMEPAGE'; 	break;
			case 250: 
			case 252: _section = 'BRAND EXPERIENCE'; 		break;
		}
		
		s.pev2 = 'FOOTER | ' + _clickedlink;
		mrm.cmp.omniture.trackChevyHF({ siteSection: _section, selection: 'FOOTER', subSelection: _clickedlink, activeState: 'INDEX'});
  });
	
	// if the short disclaimer is different than the static disclaimer then set up for rollover.
	var disabled = (typeof disableDisclaimerTreatment == 'undefined') ? false : disableDisclaimerTreatment
	//alert("disableDisclaimerTreatment = " + disabled);
	if(!disabled && $_.trim($_('#gMdsDisclaimer #shortDisclaimerContainer').html()) != $_.trim($_('#gMdsDisclaimer #staticDisclaimerContainer').html())){
		// copy the full disclaimer into the popup
		var fullDisclaimer = $_('#gMdsDisclaimer #staticDisclaimerContainer').html();
		$_('#gMdsDisclaimer #fullDisclaimerContainer #disclaimerContent').html(fullDisclaimer);
		// show the short disclaimer and the additional button
		$_('#gMdsDisclaimer #shortDisclaimerContainer').show();
		$_('#gMdsDisclaimer #addtionalDisclaimer').show();
		// hide the static disclaimer
		$_('#gMdsDisclaimer #staticDisclaimerContainer').hide();
		
		// get the disclaimer popup height
		var containerHeight = 320;//had to hard code it for opera //$_('#gMdsDisclaimer #fullDisclaimerContainer').height();
		
		// show and hide the disclaimers
		$_('#gMdsDisclaimer #shortDisclaimerContainer, #gMdsDisclaimer #addtionalDisclaimer').mouseenter(function(){
			// if it's animating don't try to show it.  this keeps it from opening and closing if the mouse is at the edge.
			if(!animating){
				// do tracking
				clickTrack({linkName: s.pageName + ' | VIEW ADDITIONAL DISCLOSURES', prop20: s.pageName + ' | VIEW ADDITIONAL DISCLOSURES', prop24: 'EN', prop25:s.prop25});
				
				animating = true;
				// reset to top each time it shows 
				$_('#gMdsDisclaimer #disclaimerContent').css('top', 0);
				
				$_("#gMdsDisclaimer #fullDisclaimerContainer").slideDown(400, function(){animating=false;});
				// calculate offset
				offset = containerHeight - $_('#gMdsDisclaimer #disclaimerContent').height();
				if(offset > 0) $_('#scroller').hide();
			}
		});
		$_('#gMdsDisclaimer #fullDisclaimerContainer').mouseleave(function(){
			// if it's animating don't try to show it.  this keeps it from opening and closing if the mouse is at the edge.
			if(!animating){
				delay = setTimeout(function(){animating = true;$_("#gMdsDisclaimer #fullDisclaimerContainer").slideUp(400, function(){animating=false;})}, 1000);
			}
		});
		
		$_('#gMdsDisclaimer a#additionalDisclaimerClose').click(function(){
			// if it's animating don't try to show it.  this keeps it from opening and closing if the mouse is at the edge.
			if(!animating){
				delay = setTimeout(function(){animating = true;$_("#gMdsDisclaimer #fullDisclaimerContainer").slideUp(400, function(){animating=false;})}, 10);
			}
			return false;
		});
		
		$_('#gMdsDisclaimer #fullDisclaimerContainer').mouseenter(function(){
			clearTimeout(delay);
		});

		// up and down button click handlers
		$_('#bottomButton').click(function (){
			iTop -= 200;
			if(iTop < offset) iTop = offset;
			$_('#gMdsDisclaimer #disclaimerContent').animate({
				top: iTop
			},500);
			return false;
		});
		$_('#topButton').click(function (){
			iTop += 200;
			if(iTop > 0) iTop = 0;
			$_('#gMdsDisclaimer #disclaimerContent').animate({
				top: iTop
			},500);
			return false;
		});
		
		$_('a#_bapw-link').mouseover(function(){
			$_(".adchoices").addClass("active");
		});
		$_('a#_bapw-link').mouseout(function(){
			$_(".adchoices").removeClass("active");
		});
	}
});