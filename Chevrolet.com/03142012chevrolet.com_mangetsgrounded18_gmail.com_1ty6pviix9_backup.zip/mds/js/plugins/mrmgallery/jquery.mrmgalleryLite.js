/**
 * MRM Image Rotate
 * - A lightweight image rotating/gallery plug-in.
 * $_('div#rotator1').mrmgalleryLite({
        images: [
            {url: '/url/file1.jpg,
             alt: 'alt tag 1',
             link: 'http://www.url.com'},
            {url:'/url/file2.jpg',
             alt: 'alt tag 2',
             link: 'http://www.url.com'}
             ]
        ,
        autoAnimate  : 2500,
        transitionSpeed: 1000,
        autoStart : true
    });
 **/

(function($)
 {
	var _defaultOptions = {
		// Public Options
    images: {}, // {imageURL: "", link: "", target: ""}
    autoAnimate  : 2500,
    transitionSpeed: 1000,
    autoStart : true
		};

	/*-----------------------------------
	* -- Function: Constructor
	* -----------------------------------*/
	$.mrmgalleryLite = function (target, options) 
	{
		/* if this contructor wasn't newed, then new it... */
		if (this == window) 
			{  return new $.mrmgalleryLite(target, (options || {}) ); } 
		else 
			{ this.init(target,options); }
	};


	/*-----------------------------------
	* -- Function: Prototype function
	* -----------------------------------*/
	$.mrmgalleryLite.prototype = {
    // properties
    target: null,
    options: null,
    slides : null,
    slideIndex : 0,
    
    /*-----------------------------------
    * -- Sub Function: Initialize Plugin
    * -----------------------------------*/
    init: function(target, options) 
    {
        this.target = $(target);
        this.options = new $.mrmgalleryLite.options(options);
        this.initRotator();        
    },
    initRotator: function() {
        var self = this;
        self.target.css({position:'relative'});
        // build HTML
        var sHTML = "";
        for(i=0;i<self.options.images.length;i++) {
            var img = self.options.images[i];
            var hasImage= (img.url != undefined);
            var hasLink = (img.link != undefined) ;
            var hasTarget = (img.target != undefined);
            var hasAlt = (img.alt != undefined);
            if (hasImage) {
                var altDesc = (hasAlt) ? ' alt="' + img.alt + '"' : '';               
                var imgHTML = '<img src="' + img.url + '"' + altDesc + ' border="0" />';
                var itemClass = (i==0) ? 'activeitem' : '';
                sHTML += '<div class="' + itemClass + '" style="position:absolute;top:0px;left:0px;display:none;">';
                if (hasLink) {
                    if (img.link.length > 0) {
                        var targetAttr = (hasTarget) ? ' target="' + img.target + '"' : '';
                        sHTML += '<a href="' + img.link + '"'+ targetAttr + '>' + imgHTML + '</a>';
                    } else {
                         sHTML += imgHTML;
                    }                    
                } else {
                    sHTML += imgHTML;
                }
                sHTML += "</div>\n";
            } else {
                continue;
            }
        }
        self.target.html(sHTML);
        this.slides = this.target.children('div');
        if (self.options.autoStart) {
            self.beginGalleryRotate();
        } else {
            self.fadeToSlide(); 
        }
        
    },
    beginGalleryRotate: function() {
        var self = this;
        if ((self.options.autoAnimate > 0) && (self.slides.length > 1)) {
            var invRot = setInterval(function() {
                self.fadeToSlide();
            }, self.options.autoAnimate);
        } else {
            self.fadeToSlide(); 
        }
    },    
    fadeToSlide : function(indexToShow) {
        var self = this;
        if (self.slides.length > 0) {
            indexToShow = (indexToShow == undefined) ? self.slideIndex : indexToShow;

            // fade in slide
            var toSlide = self.slides.eq(indexToShow);
            var fromSlide = self.slides.filter('div.activeitem');
            
            self.slides.removeClass('activeitem');
            toSlide.addClass("activeitem");
            
            fromSlide.css('z-index', 10);
            toSlide.css('z-index', 20);
            
            toSlide.fadeTo(self.options.transitionSpeed, 1, function() {
                // hide remaining
                self.slides.filter(":not(.activeitem)").hide();
            });
            // set next slide
            self.slideIndex = (indexToShow >= (self.slides.length-1)) ? 0 : self.slideIndex+1;
        }
    }
	}; // End Object

	/*-----------------------------------
	* Player - Options
	* -----------------------------------*/
	$.mrmgalleryLite.options = function (options) 
		{ $.extend( this, $.mrmgalleryLite.options, options ); };

	$.mrmgalleryLite.options.prototype = _defaultOptions;

	// expose as a selector plugin
	$.fn.mrmgalleryLite = function (options) 
	{
		return this.each(function() 
			{ new $.mrmgalleryLite(this, options); });
	};
})(jQuery);