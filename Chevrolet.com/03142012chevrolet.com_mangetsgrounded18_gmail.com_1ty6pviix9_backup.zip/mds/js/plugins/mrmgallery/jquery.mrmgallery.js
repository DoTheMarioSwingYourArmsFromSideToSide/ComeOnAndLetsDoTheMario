var _TRANSLATE3D_ = $_("html").hasClass("csstransforms3d"),
	_MULTIGALLERYCOUNT_ = 0,
	_MULTIGALLERYDELAY_ = 250;

(function($){
	// Bit Flags
    var _SOCIAL_FB_	= 1,
      _SOCIAL_TW_	= 2,
      _SOCIAL_EM_	= 4,
      _SOCIAL_DL_	= 8,
      _LOADHASH_ 	= 0,
      _CSS3_ = false,
      _TOUCHES_ = {};
      
    var _defaultOptions = {
       // Public Options
       rootImagePath		:"",
       transitionMode	:'fade',
       transitionSpeed : 1000,
       useFragments		:false,
       slideIndex			:0,
       overlaySpeed		:300,
       easing					:"easeInOutExpo",
       fullWidth				:true,
       enableShare			:true,
       enableTracking	:false,
       enableArrows		:true,
       enableKeyboard	:false,
       enableSwipe :true,
       enableTooltips	:true,
       enableThumbSlide:false,
       autoAnimate : 0,
       autoHideDots : true,
       thumbsToShow		:6,
       thumbsToSlide		:0,
       fadeArrows			:true,
       thumbsOnArrows	:false,
       countOnArrows		:false,
       spriteWidth			:150,
       thumbsSelector	:null,
       tabsSelector		:null,
       dotsSelector		:null,
       videoArea				:null,
       videoHeight : 551,
       videoWidth : 980,
       bcPlayerID: '1265519945001',
       bcPlayerKey: 'AQ~~,AAAAABQIifY~,yBcYMa-7eoJgoOGVYPXg1RwwKHr35oxe&domain=embed&dynamicStreaming=true',       
       freezeOnSwipe : false,
       slideOnExecute	:null,
       slideInProgress	:null,
       slideComplete		:null,
       videoComplete :null,
       cufonRefresh		:"",
       activeID				:"active",
       useCSS3:true,
       allowLazyLoad:false
      };

	/* -----------------------------------
	// -- Function: Constructor
	// ----------------------------------- */
	$.mrmgallery = function (target, options) 
	{
		/* if this contructor wasn't newed, then new it... */
		if (this == window) 
			{  return new $.mrmgallery(target, (options || {}) ); } 
		else 
			{ this.init(target,options); }			/* init */
	};


	/* -----------------------------------
	// -- Function: Prototype function
	// ----------------------------------- */
	$.mrmgallery.prototype = {
		/* -----------------------------------
		// -- Sub Function: Convert old options to new
		// ----------------------------------- */
	  	lastActiveSlide: 0,
	  	hasLoadedFirstTime: false,
	    slideTimeout:null,
	    useHash:false,
	    thumbsObj: null,
	    dotsObj:null,
	    galleryItems:null,
	    preloader:null,
		processOldOptions: function()
		{
			var self 		= this;
			var options	= self.options;
			
			// Standard Slide
			if (options.slideSpeed > 0)
				{ options.transitionSpeed = options.slideSpeed; }
				
			// Cross Fade
			if (options.crossFade)
			{
				options.transitionMode = 'fade';
				if (options.fadeSpeed > 0)
					{ options.transitionSpeed = options.fadeSpeed; }
			}
			
			// Old Modes
			//		slideSpeed:     	(optional) - sets the speed of the slide animation in milliseconds.
			//		fadeSpeed:      	(optional) - sets the speed of the alpha fade in milliseconds.
			//		crossFade:      	(optional) - BOOL - will change the forward and next buttons to use crossfade.

			// Replace Modes
			//		transitionMode:   (optional) - which transition type to use for slides:
			//																 -  slide - Transition the slides using a slide effect
			//																 -	fade - Cross fade the images (default)
			//																 -  wipe - Fade and slide the images
			//		transitionSpeed:  (optional) - Speed in MS to execute the transition effect
			
		},
		
		/* -----------------------------------
		// -- Sub Function: Initialize Plugin
		// ----------------------------------- */
		init: function(target, options) 
		{
			var self 				= this,
					_checkhash 	= 0,
					_count			= 0;
			
			// Are we checking for a hash
			_LOADHASH_ = window.location.hash.slice(1);
			if (_LOADHASH_.length ) { _checkhash_ = 1; }
					
			// store the basics
	    self.target 	= $(target);
	    self.options 	= new $.mrmgallery.options(options);
	
	    self.target.addClass("mrmgallery");
		
	    /* don't rerun the plugin if it is already present */
	    if (self.target.data('mrmgallery')) 
	    	{ return; }
	    
	    /* register this controlset with the element */
	    self.target.data('mrmgallery', this);
		
	    /* more init */
			self.width 			= self.target.width();
			self.height 		= self.target.height();
			self.slideIndex = self.options.slideIndex;
			self.options.slideData = new Array();
			self.galleryItems = self.target.children();
			// JQuery Objects
			self.dotsObj = $(self.options.dotsSelector);
			self.thumbsObj = $(self.options.thumbsSelector);
			if (self.options.fullWidth) self.target.addClass("fullWidth");
			if (self.options.autoAnimate > 0)
			{
				self.options.enableArrows = false;
				if ((self.dotsObj.length > 0 ) && (self.options.autoHideDots == true)) self.dotsObj.hide();
			}
			
			// Safeguard against using old methods
			self.processOldOptions();
			
		   // Set CSS3 flags
		   self.options.useCSS3 = self._checkCSS3();
		
		   // Private Variables
			self.options.kbdisable			= 0;					// Keyboard Disabled
			self.options.ts_navconwidth	= 0;					// Thumbnail slide container width (for nav buttons)
			self.options.ts_fullwidth		= 0;					// Thumbnail slide container full width
			self.options.ts_showwidth		= 0;					// Thumbnail slide set showing width
			self.options.ts_itemwidth		= 0;					// Thumbnail slide item width
			self.options.ts_itemmargin 	= 0;					// Thumbnail slide item margin
			self.options.ts_curpos			= 0;					// Thumbnail slide container Current Position
			self.options.ts_movewidth		= 0;					// Thumbnail slide move width
			self.options.ts_maxleft			= 0;					// Thumbnail maximum negative margin
	 
			/* configure slide data */
			$.each(self.galleryItems, function(index, obj) 
			{
				var imgData = {};

				/* Grab the source to build the slider
				//	img>longdesc 	- Long Description, used as a the image source
				//	img>src 			- Thumbnail or blank image
				//	-------
				//	hash-id				- HashID used for share
				//	img-desc			- Description of the image, used as footer to the image
				//	overlay				- Data to be used to build an overlay to the image
				//		> cbutton		-	1/0 to allow for closing the overlay
				//		> pbutton		- 1/0 to determine if there is a play button in the overlay Data
				//											This is templateized as [PLAY] to use the anything player */
				//		> bbutton		- 0/ID to determine if there is a play button in the overlay Data
				//											This is templateized as [PLAY] image to use the brightcove player */
				
				imgData.image = $(obj).children("img:first-child").attr("longdesc");
				imgData.thumb = $(obj).children("img:first-child").attr("src");
				if ((index==0) && self.options.allowLazyLoad) $(obj).children("img:first").addClass('lazy');
				$(obj).addClass("galleryItem");
				//$(obj).css({width:self.width+'px',height:self.height+'px'});
				if ($(obj).children(".hash-id").html().length > 0)
				{ 
					imgData.hash = $(obj).children(".hash-id").html(); 

					// Check Passed Hash against current slide
					if (imgData.hash.toLowerCase() == _LOADHASH_.toLowerCase())
						{ self.slideIndex = _count; }
				}
				else
					{ imgData.hash = ''; }
				if ($(obj).children(".img-desc").length > 0)
					{ imgData.description = $(obj).children(".img-desc").html(); }

				if ( $(obj).children(".overlay").html() != null)
				{
					if ($(obj).children(".overlay").length > 0)
					{ 
						var _text = $(obj).children(".overlay").html(); 
						_text = _text.replace('[PLAY]', '<div class="mg_play">Play Video</div>');
						_text = _text.replace('[BRIGHT]', '<div class="mg_bplay"></div>');
						_text = _text.replace('[BRIGHTSMALL]', '<div class="mg_bplay bsmall"></div>');
						imgData.overlay	= _text;
						imgData.cbutton = $(obj).children(".overlay").attr('cbutton');
						imgData.pbutton = $(obj).children(".overlay").attr('pbutton');
						imgData.bbutton = $(obj).children(".overlay").attr('bbutton');
						imgData.opacity = 50;
						if ($(obj).children(".overlay").attr('opacity'))
							{ imgData.opacity = parseInt($(obj).children(".overlay").attr('opacity')); }
					}
				}

				/* Begin the social networking disection */
				if (self.options.enableShare==true)
				{
					if ($(obj).children("span.social").html() != null)
					{
						imgData.social	= new Array();
						imgData.social['default']	= new Array('message', 'title', 'caption', 'description','thumbnail' );
        	
						/* Pull the passed options */
						var _options = $(obj).children("span.social").attr('shareopts');
						
						/* reset the options */
						imgData.social_options = 0;
        	
						/* Get the defaults */
						/* -	Get the share message */
						if ( $(obj).children("span.social").children("span.share-message").html() != null)
							{ imgData.social['default']['message'] = $(obj).children("span.social").children("span.share-message").html(); }
							
						/* -	Get the share title */
						if ( $(obj).children("span.social").children("span.share-title").html() != null)
							{ imgData.social['default']['title'] = $(obj).children("span.social").children("span.share-title").html(); }
        	
						/* -	Get the share caption */
						if ( $(obj).children("span.social").children("span.share-caption").html() != null)
							{ imgData.social['default']['caption'] = $(obj).children("span.social").children("span.share-caption").html(); }
							
						/* -	Get the share description */
						if ( $(obj).children("span.social").children("span.share-description").html() != null)
							{ imgData.social['default']['description'] = $(obj).children("span.social").children("span.share-description").html(); }
						
						/* -	Get the share thumbnail */
						if ( $(obj).children("span.social").children("span.share-thumbnail").html() != null)
							{ imgData.social['default']['thumbnail'] = $(obj).children("span.social").children("span.share-thumbnail").html(); }
        	
						/* -	Get the share download */
						if ( $(obj).children("span.social").children("span.share-download").html() != null)
							{ imgData.social['default']['download'] = $(obj).children("span.social").children("span.share-download").html(); }
						else
							{ imgData.social['default']['download'] = $(obj).children("img").attr('longdesc'); }
        	
						/* Using Facebook? */					
						if (_options.indexOf('sfb') >= 0)
						{ 
							imgData.social_options += _SOCIAL_FB_; 
							self._checkSocial(self, obj, imgData, 'sfb');
						}
        	
						/* Using Twitter? */					
						if (_options.indexOf('stw') >= 0)
						{ 
							imgData.social_options += _SOCIAL_TW_; 
							self._checkSocial(self, obj, imgData, 'stw');
						}
        	
						/* Using Email? */
						if (_options.indexOf('sem') >= 0)
						{ 
							imgData.social_options += _SOCIAL_EM_; 
							self._checkSocial(self, obj, imgData, 'sem');
						}
        	
						/* Using Download? */
						if (_options.indexOf('sdl') >= 0)
						{ 
							imgData.social_options += _SOCIAL_DL_; 
							self._checkSocial(self, obj, imgData, 'sdl');
						}
					}
				}
				self.options.slideData.push(imgData);
				
    		_count++;
			});
			
			self.num_slides = this.options.slideData.length;
			
			/* clean slide index */
			if (self.slideIndex > self.num_slides-1) 
				{ self.slideIndex = self.num_slides-1; }
				
			if (self.slideIndex < 0) 
				{ self.slideIndex = 0; }
				
			window.shareimage = this.options.slideData[self.slideIndex].image;
			var thisCount = _MULTIGALLERYCOUNT_;
			var thisTime = (_MULTIGALLERYCOUNT_*_MULTIGALLERYDELAY_);
			if (_ISMOBILE_) {
				 setTimeout(function() {
					 self.initGallery(); 
					 self.createEventListeners();
			    }, (_MULTIGALLERYCOUNT_*_MULTIGALLERYDELAY_));
			    _MULTIGALLERYCOUNT_++;
			} else {
				 self.initGallery();
				 self.createEventListeners();
			}
   
		},
	
		/* -----------------------------------
		// -- Sub Function: Initialize Gallery
		// ----------------------------------- */
		initGallery: function() 
		{
			var self = this;
			var options = self.options;
		
			/* create initial div properties */
			var div_list = self.galleryItems;

			
			// add arrows
			if (self.options.enableArrows && self.num_slides > 1) 
			{

				/* ------- PREVIOUS --------- */				
				var _thumbsel = '';
				var _countsel = '';
				var _left			= 0;
				/* If using the Counts on Arrows */
				if (self.options.thumbsOnArrows && self.options.thumbsSelector != null) 
				{ 
					_thumbsel = '<div class="thumb" style="left:' + _left + 'px;width:' + self.options.spriteWidth + 'px;"></div>';
					_left += self.options.spriteWidth;
				}

				/* If using the Thumbnails on Arrows  */
				if (self.options.countOnArrows && self.options.thumbsSelector != null) 
					{ _countsel = '<div class="count" style="left:' + _left + 'px;"></div>'; }


				var top = (self.height/2)-41;
				var arrowPrev = $('<div class="mrmgallery-arrow prev" style="top:'+top+'px">'
												+		'<a>'
												+			'<div class="slide">'
												+				_thumbsel
												+				_countsel
												+			'</div>'
												+		'</a>' 
												+ '</div>');
												
												
				/* ------- NEXT --------- */				
				var _thumbsel = '';
				var _countsel = '';
				var _left			= 0;
				/* If using the Counts on Arrows */
				if (self.options.countOnArrows && self.options.thumbsSelector != null) 
				{ 
					_countsel = '<div class="count" style="left:' + _left + 'px;"></div>';  
					_left += 55;
				}

				/* If using the Thumbnails on Arrows  */
				if (self.options.thumbsOnArrows && self.options.thumbsSelector != null) 
					{  _thumbsel = '<div class="thumb" style="left:' + _left + 'px;width:' + self.options.spriteWidth + 'px;"></div>';  }

												
				var arrowNext = $('<div class="mrmgallery-arrow next" style="top:'+top+'px">'
												+		'<a>'
												+			'<div class="slide">'
												+				_countsel
												+				_thumbsel
												+			'</div>'
												+		'</a>' 
												+ '</div>');
				self.target.append(arrowPrev).append(arrowNext);
			}
			
			// add description div
			var desc = self.options.slideData[self.slideIndex].description;
			if (desc) 
			{
				var descDiv = $('<div class="mrmgallery-desc"></div>');
				self.target.append(arrowPrev).append(descDiv);
			
				//set description for slide
				descDiv.html(self.options.slideData[self.slideIndex].description);
			}
			
			// configure thumbs
			if (self.options.thumbsSelector) 
			{
				$(self.options.dotsSelector).addClass('thumb_nav');				
				var thumbs = $(self.options.thumbsSelector).children();
				$(self.options.thumbsSelector).parent().parent().addClass("mrmgallery-thumbnav");

				thumbs.eq(self.slideIndex).addClass(self.options.activeID);
				if (self.options.enableThumbSlide) 
				{
					var _zoomfactor = 1;
					if (_ISMOBILE_)
						{ _zoomfactor = parseFloat( $('body').css('zoom') ); }
					self.options.ts_fullwidth		= $(self.options.thumbsSelector).width();
					self.options.ts_navconwidth	= $(self.options.thumbsSelector).parent().parent().width();
					self.options.ts_showwidth		= $(self.options.thumbsSelector).parent().width() ;
					self.options.ts_itemwidth		= thumbs.eq(self.slideIndex).width();
					self.options.ts_itemmargin	= parseInt(thumbs.eq(self.slideIndex).css('margin-left')) + parseInt(thumbs.eq(self.slideIndex).css('margin-right')) / _zoomfactor;
					var _arrowpos = ((self.options.ts_navconwidth - self.options.ts_showwidth - 65)/2) / _zoomfactor;
					//var _arrowpos = (_TOUCHLOADED_ == 1) ? 0 : ((self.options.ts_navconwidth - self.options.ts_showwidth - 65)/2) / _zoomfactor;					
					
					$(".mrmgallery-thumbnav").append(	'<div class="mrmgallery-navarrowcontainer" style="left:' + _arrowpos + 'px;"><div class="mrmgallery-navarrow prev"></div></div>'
																				+		'<div class="mrmgallery-navarrowcontainer" style="right:' + _arrowpos + 'px;"><div class="mrmgallery-navarrow next"></div></div>');

					// Determine the amount each button (L/R) click will move the thumbs
					if (self.options.thumbsToSlide == 0)
					{ 
						self.options.thumbsToSlide 	= self.options.thumbsToShow;
						self.options.ts_movewidth 	= (self.options.ts_showwidth + self.options.ts_itemmargin);
					} else {
						self.options.ts_movewidth	= ((self.options.ts_itemwidth + self.options.ts_itemmargin) * self.options.thumbsToSlide);
					}
					self.options.ts_maxleft			= (self.options.ts_fullwidth - (self.options.thumbsToShow * (self.options.ts_itemwidth + self.options.ts_itemmargin) ) );
				}
			}
			
			// configure tabs
			if (self.options.tabsSelector) 
			{
				$(self.options.dotsSelector).addClass('tab_nav');
				var tabs = $(self.options.tabsSelector).children();
				tabs.eq(self.slideIndex).addClass(self.options.activeID);
			}
			
			// configure dots
			if (self.options.dotsSelector) 
			{
				$(self.options.dotsSelector).addClass('dot_nav');
				var dots = $(self.options.dotsSelector).children();
				$(self.options.dotsSelector).children('li').each(function(index){
					$(this).addClass('dotsel'+index);
				});
				
				dots.eq(self.slideIndex).addClass(self.options.activeID);
			}
    	
			self.shiftSlides();
			self.setPostProcessingOptions();
			self.clearSlideOptions('', 0);   
    
	if (self.options.autoAnimate > 0){
		setInterval (function() {
			self.nextSlide ();
		}, self.options.autoAnimate);
	}
	
	// Add preload elements
	self.target.append("<div class='preloader' style='width:100%;height:100%;display:none;'><img src='../assets/en/images/ajax-loader.gif' /></div>");
	self.preloader = self.target.children('div.preloader:first');
	if (self.target.children('div.mg_share').length > 0) self.preloader.addClass("hasSharing");
    
	},

		 /* -----------------------------------
		// -:- Sub Function: Check for CSS3 Transitions/Animations
		// ----------------------------------- */
	   _checkCSS3: function()
	    {
	        // Only use CSS3 if we are on a Mobile device
		   var ret = false;	       
	       if (this.options.useCSS3 && _ISMOBILE_ && _TRANSLATE3D_ && (this.galleryItems.length > 1)) {
	        	ret = true;
	        	//this.target.css("-webkit-backfaceVisibility", "hidden");
	        }
	        return ret;     
	    },              
	  /* -----------------------------------
		// -:- Sub Function: Reposition Slides in order
		// ----------------------------------- */
		shiftSlides : function(callLeftOffset) 
		{
			var self = this;
			
			var options = self.options;
			var slideIndex = self.slideIndex;
			var slideData = options.slideData;
			
			var currImage = self.galleryItems.eq(slideIndex).find("img");
			var currCurrSource = currImage.attr("src");
			var currFullSource = currImage.attr("longdesc");
			
			// TODO: Need to handle loading here
			if (self.options.fullWidth) 			// create backround divs of the images
			{ 
				//TODO: Only Remove on images that this has not been set
				// remove the images
				if (self.options.transitionMode != 'wipe') {currImage.css("display","none");}
			
				// add divs with backgrounds
				var currBackground = "url('"+currFullSource+"') no-repeat center center";
				var currDiv = self.galleryItems.eq(slideIndex);	
				var nextDiv =  self.galleryItems.eq(self.nextSlideIndex());
				var prevDiv = self.galleryItems.eq(self.prevSlideIndex());
				// preload just the immediate
				if (currDiv.children("div.fullwidth-image").length == 0) 
				{// set the pre image to the full image
					var newDiv = $('<div class="fullwidth-image"></div>');
					newDiv.css({'background': currBackground,
		                 'width': self.width,
		                 'height':self.height});
					currDiv.append(newDiv);
					
				}		
				if (nextDiv.children("div.fullwidth-image").length == 0)
					nextDiv.append('<div class="fullwidth-image" style="width:' + self.width + 'px;height:' + self.height + 'px;"></div>');
				if (prevDiv.children("div.fullwidth-image").length == 0)
					prevDiv.append('<div class="fullwidth-image" style="width:' + self.width + 'px;height:' + self.height + 'px;"></div>');
				
				delete currentDiv;
				delete nextDiv;
				delete prevDiv;
			} else {
				
				if ((currCurrSource != currFullSource) && (!self.options.allowLazyLoad || this.hasLoadedFirstTime))
				{ 
					currImage.attr("src",currFullSource);
				}	
			} // set the pre image to the full image			}
			this.hasLoadedFirstTime = true;
			self.shiftLefts(callLeftOffset);
		
			// Set the counts if used
			self.setPostProcessingOptions();
		
			// allow for gallery actions.
			self.safeToAnimate = true;
		
			// If overlay on new slide
			if (typeof(slideData[slideIndex].overlay) != 'undefined') 
			{
				if (slideData[slideIndex].overlay.length > 0) 
					{ self.clearSlideOptions('in', slideIndex); }
			}
   
			this.lastActiveSlide = slideIndex;
		},
		
		/* -----------------------------------
		// -- Sub Function: Clear Slide Options (Share/Overlay/Video)
		// ----------------------------------- */
		clearSlideOptions: function(_mode, _index)
		{
			var self = this;
			
			var options 		= self.options;
			var slideIndex 	= self.slideIndex;
			var slideData 	= options.slideData;

			// ==============================
			// == Area: Overlay 
			// ==============================
			if (slideData[_index].overlay != null)
			{
				_overlay = '';
				switch (_mode)
				{
					default:
					case 'in':
						if (self.target.children('div.mg_overlay').html() != null)
							{ self.target.children('div.mg_overlay').remove(); }
							
						/* Unbind as a sanity measure */
						$("div.mg_overlay div.mg_close").die('click');
						$("div.mg_overlay div.mg_overlaywrapper div.mg_play").die('click');
						$("div.mg_overlay div.mg_overlaywrapper div.mg_bplay").die('click');
						
						/* Build the overlay */
						var _overlay 	= '<div class="mg_overlay" id="mgo_' + _index + '" style="background:rgba(0,0,0, ' + (slideData[_index].opacity / 100) + ');">'
													+ 	(( slideData[_index].cbutton == 1) ? '<div class="mg_close"></div>' : '' )
													+		'<div class="mg_overlaywrapper">'
													+			slideData[_index].overlay
													+		'</div>'
													+	'</div>';
						
						
						self.target.append(_overlay);
						self.target.children('div.mg_overlay').fadeTo(options.overlaySpeed, 1, function() 
							{ self.cufonRefresh();  });
						
						/* Bind the close button */
						if (slideData[_index].cbutton == 1)
						{
							$('div.mg_overlay div.mg_close').live('click', function() {
							  self.closeOverlay();
							});
						}
						
						/* Bind the Play Button */
						if (slideData[_index].pbutton == 1)
						{
							$('div.mg_overlay div.mg_overlaywrapper div.mg_play').stop().live(_MOVEMENTS_.click, function() 
							{
				    	  $(self.options.videoArea).fadeTo(100, 1).show();
				    	  DataStack.AnythingPlayer.options.navActiveIndex = slideIndex;
				    	  DataStack.AnythingPlayer.buildThePlayer();
							});
						}

						/* Bind the Brightcove Play Button */
						if ((slideData[_index].bbutton != 0) && (slideData[_index].bbutton != undefined))
						{
							$('div.mg_overlay div.mg_overlaywrapper div.mg_bplay').stop().live(_MOVEMENTS_.click, function() 
							{
								
								var _validplay = true;
								if (_ISMOBILE_) 
									{ _validplay = iosDetect(0, 0, true, true); }
									
								if ( _validplay )
								{
									// HTML5
									 $.ajax({
										  type: "GET",
										  url: 'http://admin.brightcove.com/js/BrightcoveExperiences_all.js',
										  cache: true,
										  success: function() {
								    		  $(self.options.videoArea).fadeTo(100, 1).show();
								    		  var _multiplier = 1;
								    		  if (_ISMOBILE_)
								    		  	{ _multiplier = parseFloat( $('body').css('zoom') ); }
		
								    		  var _videoheight 	= (self.options.videoHeight * _multiplier);
								    		  var _videowidth 	= (self.options.videoWidth * _multiplier);
								    		  
								    		  var _videoplayer =	'<div class="mrm_videoholder">'
																			+			'<div class="mrm_videoclose"><img src="../assets/en/images/global/overlay_close.jpg" /></div>'
																			+ 		'<object id="myExperience'+slideData[_index].bbutton+'" class="BrightcoveExperience">'
																			+				'<param name="bgcolor" value="#FFFFFF" />'																	
																			+				'<param name="width" value="'+_videowidth+'" />'
																			+				'<param name="height" value="'+_videoheight+'" />'																	
																			+				'<param name="wmode" value="transparent" />'
																			+				'<param name="playerID" value="' + self.options.bcPlayerID + '" />'
																			+				'<param name="playerKey" value="' + self.options.bcPlayerKey + '" />'
																			+				'<param name="isVid" value="true" />'
																			+				'<param name="isUI" value="true" />'
																			+				'<param name="dynamicStreaming" value="true" />'
																			+				'<param name="autoStart" value="true" />'
																			+				'<param name="@videoPlayer" value="'+slideData[_index].bbutton+'" />'
																			+			'</object>'
																			+		'</div>'
																			+ 	'<script>brightcove.createExperiences();</script>';
																					
								    		  $(self.options.videoArea).html(_videoplayer);
										  },
									  dataType: "script",
									  cache: true});
							
								}
							});
						}
						break;
					case 'out':
        if (_ISMOBILE_) {
            self.target.children('div.mg_overlay').remove();
        } else {
            self.target.children('div.mg_overlay').fadeTo(options.overlaySpeed, 0, function() 
        {
         self.target.children('div.mg_overlay').remove();
        });
        }
						
						break;
				}
    
			}

			// If there is a video playing, stop it
			if ($(self.options.videoArea).is(':visible'))
				{ $(self.options.videoArea).fadeTo(150, 0, function() { $(self.options.videoArea).hide(); } ); }
			
		},

		// -----------------------------------
		// -- Function: Reset Social Options
		// -----------------------------------
		resetSocialOptions: function(_slideIndex)
		{
			var self = this;
			var options 		= self.options;
			var slideIndex 	= self.slideIndex;
			var slideData 	= options.slideData;
			
			if ((slideData[_slideIndex].social_options == 0) || (slideData[_slideIndex].social_options == undefined) || (self.options.enableShare == false))
				{ return; }
				
			var _socialtext 	= '';
			var _downloadtext = '';
			var _socialcount 	= 0;
			var	_spritewidth	= 69;
			var	_spriteheight	= 69;
			var _marginleft 	= 0;
			var _maxwidth			= 0;
			var host 			= window.location.host;
			var protocol 	= window.location.protocol;
			var pathname 	= window.location.pathname;

			/* Unbind as a sanity measure */
			self.target.find("div.mg_share").die(_MOVEMENTS_.click);
			self.target.find("div.mg_share div.mg_socialshare").die(_MOVEMENTS_.mouseover);
			self.target.find("div.mg_share div.mg_socialshare").die(_MOVEMENTS_.mouseout);
			self.target.find("div.mg_share div.mg_socialshare div.mg_buttons div.mg_socialbutton.mg_facebook").die(_MOVEMENTS_.click);
			self.target.find("div.mg_share div.mg_socialshare div.mg_buttons div.mg_socialbutton.mg_twitter").die(_MOVEMENTS_.click);
			self.target.find("div.mg_share div.mg_socialshare div.mg_buttons div.mg_socialbutton.mg_email").die(_MOVEMENTS_.click);
			self.target.find("div.mg_share div.mg_socialshare div.mg_buttons div.mg_socialbutton.mg_download").die(_MOVEMENTS_.click);
   
   var previousShareLinkVisible = false;
			if (self.target.children('div.mg_share').html() != null)
				{   previousShareLinkVisible = (parseInt(self.target.children('div.mg_share').css("opacity")) > 0);
        self.target.children('div.mg_share').remove(); }

			// ==============================
			// == Area: Share
			// ==============================
			// Do we have social shares?
			if (slideData[_slideIndex].social_options > 0 )
			{
				if (slideData[_slideIndex].social_options & _SOCIAL_FB_	) { _socialcount++;}
				if (slideData[_slideIndex].social_options & _SOCIAL_TW_	)	{ _socialcount++;}
				if (slideData[_slideIndex].social_options & _SOCIAL_EM_	)	{ _socialcount++;}
				if (slideData[_slideIndex].social_options & _SOCIAL_DL_	)	{ _socialcount++;}

				_marginleft = 0;
				_marginleft = (((_socialcount * _spritewidth) / 2) * -1);
				_maxwidth		= (_socialcount*_spritewidth);
				
				_socialtext = '<div class="mg_socialshare">'
										+		'<div class="mg_openshare"></div>'
										+		'<div class="mg_buttons" style="width:'+_maxwidth+'px;margin-left:'+_marginleft+'px;">';
				if (slideData[_slideIndex].social_options & _SOCIAL_FB_	)
					{  _socialtext += '<div class="mg_socialbutton mg_facebook"></div>'; }
				
				if (slideData[_slideIndex].social_options & _SOCIAL_TW_	)
					{  _socialtext += '<div class="mg_socialbutton mg_twitter"></div>'; }
					
				if (slideData[_slideIndex].social_options & _SOCIAL_EM_	)
					{ _socialtext += '<div class="mg_socialbutton mg_email"></div>'; }

				if (slideData[_slideIndex].social_options & _SOCIAL_DL_	)
					{ _socialtext += '<div class="mg_socialbutton mg_download"></div>'; }
				
				_socialtext += 	'</div>'
										+	'</div>';
				
			}
					
			/* Build the share link */
			var _overlay 	= '<div class="mg_share" style="width:'+_maxwidth+'px;margin-left:'+_marginleft+'px;" rel="' + _slideIndex + '">'
										+		_socialtext
										+		_downloadtext
										+	'</div>';
			self.target.append(_overlay);
			if (previousShareLinkVisible) self.target.children("div.mg_share").show();
//			//When hovering arrows hide share
			self.target.find( '.mrmgallery-arrow a' ).hover(
				function(){
					self.target.find( 'div.mg_share' ).hide();
				},
				function(){
					self.target.find( 'div.mg_share' ).show();
				}
			);
//			// Create the hover event on the share button
			self.target.find('div.mg_share div.mg_socialshare div.mg_openshare').live( 'mouseenter', function(event){
				self.target.find('div.mg_share div.mg_socialshare div.mg_buttons').show();
			});
			self.target.find('div.mg_share div.mg_socialshare div.mg_openshare').live(_MOVEMENTS_.click, function(event){ 
				self.target.find('div.mg_share div.mg_socialshare div.mg_buttons').show();
			});
//			self.target.find('div.mg_share').find('div.mg_socialshare').live(_MOVEMENTS_.mouseout, function(event)
//			{
//				self.target.find('div.mg_share div.mg_socialshare div.mg_buttons').hide(); 
//			});
			self.target.find('div.mg_share div.mg_socialshare div.mg_buttons').hover(
				function(){
					//intentionally do nothing.
				},
				function(){
					self.target.find('div.mg_share div.mg_socialshare div.mg_buttons').hide(); 
				}
			);
	var postURL = window.location.href.split('#')[0];
	if (slideData[_slideIndex].hash.length) postURL += '#' + slideData[_slideIndex].hash;
			// check the specific options to link
			//	-	Facebook
			if (slideData[_slideIndex].social_options & _SOCIAL_FB_	) 
			{ 
				self.target.find('div.mg_share div.mg_socialshare div.mg_buttons div.mg_socialbutton.mg_facebook').live(_MOVEMENTS_.click, function(event) 
				{
					_message = self.getSocial(self, slideData[_slideIndex].social, 'sfb');
				
					if (_message['thumbnail'].length < 1)
					{
						MRMSocial.fbPublish(
															_message['message'			] + '&nbsp;',
															_message['title'				] + '&nbsp;',
															_message['caption'			] + '&nbsp;',
															_message['description'	] + '&nbsp;',
															postURL 
						);
					} else {
						// Update the thumbnail with the path
						_message['thumbnail'] = protocol + '//' + host + _message['thumbnail'];
						MRMSocial.fbPublishGalleryItem(
															_message['message'			] + '&nbsp;',
															_message['title'				] + '&nbsp;',
															_message['caption'			] + '&nbsp;',
															_message['description'	] + '&nbsp;',
															_message['thumbnail'		],
															postURL 
						);
					}

				});
			};
			
			//	-	Twitter
			if (slideData[_slideIndex].social_options & _SOCIAL_TW_	)	
			{ 
				self.target.find('div.mg_share div.mg_socialshare div.mg_buttons div.mg_socialbutton.mg_twitter').live(_MOVEMENTS_.click, function(event) 
				{
					_message = self.getSocial(self, slideData[_slideIndex].social, 'stw');
					MRMSocial.tweet( postURL , _message['description']);
					
				});
			};
			
			//	-	Email
			if (slideData[_slideIndex].social_options & _SOCIAL_EM_	)	
			{ 
				self.target.find('div.mg_share div.mg_socialshare div.mg_buttons div.mg_socialbutton.mg_email').live(_MOVEMENTS_.click, function(event) 
				{
					_message = self.getSocial(self, slideData[_slideIndex].social, 'sem');
					var _shareMessage 		= _message['description']
																+ "\n\n" 
																+ postURL
																+ "\n\n" 
																+ "This email does not add the sender's or recipient's email address to the Chevrolet marketing email list. However, if you provided us your email address, or we received it through some other source, we may use it in accordance with our privacy statement at http://www.gm.com/privacy ."
					MRMSocial.email(_message['title'], _shareMessage);
				});
			};

			//	-	Download
			if (slideData[_slideIndex].social_options & _SOCIAL_DL_	)	
			{ 
				self.target.find('div.mg_share div.mg_socialshare div.mg_buttons div.mg_socialbutton.mg_download').live(_MOVEMENTS_.click, function(event) 
				{
					_message = self.getSocial(self, slideData[_slideIndex].social, 'sdl');
					window.open(location.protocol + '//' + location.host + _message['download'], null);
				});
			};
			
		},

		/* -----------------------------------
		// -- Sub Function: Close Overlay
		// ----------------------------------- */
		closeOverlay: function()
		{
			var self = this;
			var options 		= self.options;

			self.target.children('div.mg_overlay').fadeTo(options.overlaySpeed, 0, function() 
			{
				self.target.children('div.mg_overlay').remove();
				$("div.mg_overlay div.mg_close").unbind(_MOVEMENTS_.click);
			});
		},

		// -----------------------------------
		// -- Sub Function: Set the options after competing tasks
		// -----------------------------------
		setPostProcessingOptions: function()
		{
			var self = this;
			
			// If countOnArrows - Change the display			
			if (self.options.countOnArrows)
			{
				var _prev = (self.prevSlideIndex() + 1) + ' / ' + self.num_slides ;
				var _next = (self.nextSlideIndex() + 1) + ' / ' + self.num_slides ;

				// Set the counts				
				self.target.find('div.mrmgallery-arrow.next a div.slide div.count').text( _next );
				self.target.find('div.mrmgallery-arrow.prev a div.slide div.count').text( _prev );
			}

			// If thumbsOnArrows - Change the display			
			if (self.options.thumbsOnArrows)
			{
				// Set the Thumbnails
				var _background = ( (self.nextSlideIndex() * self.options.spriteWidth) * -1);
				self.target.find('div.mrmgallery-arrow.next a div.slide div.thumb').css({'background-position': _background });
				
				var _background = ( (self.prevSlideIndex() * self.options.spriteWidth) * -1);
				self.target.find('div.mrmgallery-arrow.prev a div.slide div.thumb').css({'background-position': _background });
			}			
			// Set Active Indicators
			self.setIndicators();
			// Reset the social options 
			self.resetSocialOptions(self.slideIndex);
			
			// Check for any Cufon Refresh
			self.cufonRefresh();
			
		},	

		/* -----------------------------------
		// -- Sub Function: Reposition Slides
		// ----------------------------------- */
		shiftLefts: function(e) 
		{
   var callOffset = (e == true);
     
			var self = this;
			var slideIndex = self.slideIndex;
			var prevSlideIndex = self.prevSlideIndex();
		
			// shift lefts of gallery divs
			var div_list = self.target.children(".galleryItem");

			self.target.children(".galleryItem").removeClass('activeitem');
			self.target.children(".galleryItem").eq(self.slideIndex).addClass('activeitem');
			// move the previous slide before, move the rest of the slides after.
			if ((self.options.transitionMode != 'wipe') && callOffset)
			{
				$.each(div_list, function(index, obj) 
				{
					var offSet = 0;
					
					if (index == prevSlideIndex) 				// set the previous image off screen to the left
						{  offSet = -self.width; } 
					else if (index != slideIndex) 			// set all other images off screen to the right
						{  offSet = self.width; }
					
     $(obj).css("left", offSet+"px");
				});
			}
		},
	
		/* -----------------------------------
		// -- Sub Function: Slide Shift - Next
		// ----------------------------------- */
		nextSlide: function(e) 
		{
			this.goToSlide(this.nextSlideIndex());
		},
	
		/* -----------------------------------
		// -- Sub Function: Slide Shift - Previous
		// ----------------------------------- */
		prevSlide: function(e) 
		{
			this.goToSlide(this.prevSlideIndex());
		},
	
		// ===========================================================================
		// == Area: Transitions Begin 
		// ===========================================================================
		/* -----------------------------------
		// -:- Sub Function: Preload Slide -
		// ----------------------------------- */
    preloadCSSSlide: function(slideObject) {
        var self = this;
        var prevCSS = slideObject.attr("style");        
        var resetObj = {        
        "visibility": "",
        "opacity" : ".01",
        "left":(self.width/2),
        "z-index":"30",
        "display": "",
        "margin-left": ""
        };
        var tmpImage = $("<img>");
        tmpImage.hide();
        tmpImage.bind("load", function() {
            tmpImage.remove();           
        });
        tmpImage.attr('src', slideObject.find("img").attr("longdesc"));
    },
    preloadImage: function(slideIndex, onComplete) {
    	 var self = this;
    	 var isLoaded = false;
    	 var currSlide = self.galleryItems.eq(slideIndex)
         var currImage = currSlide.find("img:first");
    	 var currSource = currImage.attr("src");
		 var currFullSource = currImage.attr("longdesc");
		 if (self.options.fullWidth) {
			 isLoaded = (currSlide.children('div.fullwidth-image').css('background-image') != 'none'); 
		 } else {
			 isLoaded = (currSource == currFullSource);
		 }
		 if (!isLoaded) {
			 var tmpImage = $("<img>");
	    	 tmpImage.hide();
	         tmpImage.bind("load", function() {
	             tmpImage.remove(); 
	             delete tmpImage;
	             // set the image 
	 			 if (self.options.fullWidth) {
	 				 currSlide.children('div.fullwidth-image').css({
	 						 backgroundImage: "url('" + currFullSource + "')",
	 						 width: self.width,
	 						 height: self.height});
	 			 } else {
	 				 if (currSource != currFullSource) {
	 					 currImage.attr('src', currFullSource);
	 				 }
	 			 }
	 			 if (self.options.useCSS3) {
	 	             self.preloader.css({"opacity": "0", "display": "none"});
	 	         } else {
	 	        	self.preloader.stop().fadeTo(200, 0, function() {self.preloader.hide();});
	 	         }   	 			
	             if ($.isFunction(onComplete)) onComplete();
	         });
	         // fade in preloader
	         self.preloader.show(function() {
	        	 if (self.options.useCSS3) {
		        	 self.preloader.css(_css3Property("transition", "opacity 200ms ease-in-out"));
		             self.preloader.css({"opacity": ".7"});
		         } else {
		        	 self.preloader.fadeTo(200, .5);
		         }
	         });
	                  
	         tmpImage.attr('src', this.galleryItems.eq(slideIndex).find("img").attr("longdesc"));
		 } else {
			 // already preloaded, so just fire the onComplete function
			 if ($.isFunction(onComplete)) onComplete();
		 }
    	
    },
 	/* -----------------------------------
		// -:- Sub Function: Slide In 
		// ----------------------------------- */
    slide : function(directionOrSlideIndex) 
		{    		
			var self = this;
			if (self.num_slides == 1) 
				{ return; }
		   if (self.safeToAnimate) {
			   self.safeToAnimate = false;
				var	direction = "next",
					currentSlideIndex = self.slideIndex;
		   if (!self.target.hasClass("slide")) self.target.addClass("slide");
		   self.target.removeClass("fadeToSlide");
		   self.target.removeClass("wipeToSlide");
   
		   // check if parm is numeric
		   if (typeof(directionOrSlideIndex) == 'number') {
			   var newSlideIndex = directionOrSlideIndex;
			   if (newSlideIndex > self.slideIndex) {
				   direction = "next";
				   self.slideIndex = newSlideIndex-1;
			   } else if (newSlideIndex < self.slideIndex) {
				   direction = "prev";	
				   self.slideIndex = newSlideIndex+1;
			   } else {
				   return;
			   }	
			   
		   } else {
			   direction = directionOrSlideIndex;
		   }
		   
			var options = self.options;
			var slideData = options.slideData;
			var slideIndex = self.slideIndex;		 
			
			if(direction=='next') 			/* increment slideIndex */
				{ self.slideIndex = (self.slideIndex < self.num_slides-1) ? self.slideIndex+1 : 0; }
			else												/* previous - decrement slideIndex */
				{  self.slideIndex = (self.slideIndex > 0) ? self.slideIndex-1 : self.num_slides-1; }
				
			var slideIndex = self.slideIndex;   
			var preloadSlideIndex = (direction == "next") ?  self.nextSlideIndex() : self.prevSlideIndex();
			
				//self.setIndicators();
				// preload slide
				self.preloadImage(slideIndex, function() {	
				var currentSlide = self.galleryItems.eq(currentSlideIndex);
				var nextSlide = self.galleryItems.eq(slideIndex);
			    var preloadSlide = self.galleryItems.eq(preloadSlideIndex);
			    
			    self.galleryItems.filter(":not(.activeitem)").css("display", "none");
				nextSlide.css("display", "");
	    
					var group = [currentSlide,nextSlide,preloadSlide];
					var transitionSpeed = options.transitionSpeed;  
					var intAmountToMove = (direction == "next") ? -parseInt(self.width) : parseInt(self.width);  
					
					// slide On Execute callback 
					$.isFunction(options.slideOnExecute) && options.slideOnExecute.call(self, slideIndex);
					       
					$.each(group, function(index,obj)
					{
				        var curLeft = obj.position().left;
				        if ((index == 1) && (curLeft == 0))     
				            curLeft = (direction == "next") ? parseInt(self.width) + "px" : -parseInt(self.width) + "px";
				             
				        obj.children("div.fullwidth-image").css("visibility", "");
				               
				        switch(index) {
				         case 0:
				         case 1:			
				             // These are applied to both the slide about to slide in and the slide that is sliding out
				             
				             // resets    
				        	 var thisLeft = (index == 1) ? -intAmountToMove : curLeft;
				             obj.css("z-index", (index == 0) ? "" : 20);
				             obj.css({"display": "",
				            	 	  "left":thisLeft});             
				             
				             // If CSS3, then animate using CSS
				             if (self.options.useCSS3) {
				                 obj.css({"opacity" : ""});                    
				                 obj.css(_css3Property("transition", "BROWSERtransform 0ms ease-in-out"));
				                 obj.css(_css3Property("transform", "translate(0px, 0px)"));                
				                  // animate slide 
				                 obj.show().show(function() {
								 
				                    // animate slide
				                    obj.css(_css3Property("transition", "BROWSERtransform " + transitionSpeed + "ms ease-in-out"));
				                    obj.css(_css3Property("transform", "translate(" + intAmountToMove + "px, 0px)"));                     
				                 });
				             } else {
				                  // Otherwise, animate using JQuery            	
				                 obj.animate
				                 ({left: (thisLeft + intAmountToMove) + "px"}, 
				                  options.transitionSpeed, 
				                  options.easing, 
				                  function() {					
				                     $(".mrmgallery-thumbnav div.mrmgallery-navarrowcontainer").removeClass('inactive');
				                     if (index == 1) {
				                    	 currentSlide.css({"left" : 0,
				                             "opacity" : ""});
								         currentSlide.css(_css3Property("transition", ""));
								         currentSlide.css(_css3Property("transform", "")); 
								         currentSlide.css("left", intAmountToMove);                 
								         nextSlide.css({"left" : 0,
								                          "opacity" : ""});
								         nextSlide.css(_css3Property("transition", ""));
								         nextSlide.css(_css3Property("transform", "")); 
								                         
								           // clean up
								        
								         self.setIndicators();
								         self.shiftSlides(false);								         
								         $(".mrmgallery-thumbnav div.mrmgallery-navarrowcontainer").removeClass('inactive');
								         $.isFunction(options.slideComplete) && options.slideComplete.call(self, self.slideIndex);
								         $('.galleryItem.activeitem').css('filter','');
								         $('.mrmgallery').css('filter','');
								         self.safeToAnimate = true;

				                     }
				                     
									}
				                 );
				             }
				             break;
				         case 2:			
				             // this is a preloaded slide for performance   
				        	 if (currentSlideIndex != preloadSlideIndex) {
				        		 obj.css("left", -intAmountToMove);  
				                 window.setTimeout(function() {
				               	  self.preloadCSSSlide(preloadSlide);
				                 }, transitionSpeed);
				        	 }             
				             break;
				        }          
				    });
					
					currentSlide.bind('webkitTransitionEnd mozTransitionEnd oTransitionEnd transitionend msTransitionEnd', function()
			            {
							currentSlide.unbind();
				            currentSlide.css({"left" : 0,
				                                "opacity" : ""});
				            currentSlide.css(_css3Property("transition", ""));
				            currentSlide.css(_css3Property("transform", "")); 
				            currentSlide.css("left", intAmountToMove);                 
				            nextSlide.css({"left" : 0,
				                             "opacity" : ""});
				            nextSlide.css(_css3Property("transition", ""));
				            nextSlide.css(_css3Property("transform", "")); 
				                            
				              // clean up
				            self.setIndicators();
				            self.shiftSlides(false);	
				            self.safeToAnimate = false;
				            $(".mrmgallery-thumbnav div.mrmgallery-navarrowcontainer").removeClass('inactive');
				            $.isFunction(options.slideComplete) && options.slideComplete.call(self, self.slideIndex);
				            $('.galleryItem.activeitem').css('filter','');
				            $('.mrmgallery').css('filter','');
				            window.setTimeout(function() {self.safeToAnimate = true;}, 500);
			            }
					
					);
				// Set the counts if used
				self.useHash = true;
				self.setPostProcessingOptions();
				
			});

			
	
		   } else {
			   console.log('not safe');
		   }
		},

		/* -----------------------------------
		// -:- Sub Function: Slide Fade 
		// ----------------------------------- */
		fadeToSlide : function(toSlideIndex,animated) 
		{
			
			/* check for animated argument - Set to default if not sent */
			(typeof(animated) == 'undefined') ? animated = true : null;
		
			var self 		= this;
			var options = self.options;
   
		   // manage class naming
		   if (animated) {
		        if (!self.target.hasClass("fadeToSlide")) self.target.addClass("fadeToSlide");
		        self.target.removeClass("wipeToSlide");
		        self.target.removeClass("slide");
		   }
		   self.galleryItems.find("div.fullwidth-image").css("visibility", "");
		   self.target.hide(0, function(){$(this).show()});
			if (self.num_slides == 1) 
				{ return; }
		
			/* check for valid slide index */
			if (toSlideIndex > self.num_slides-1) { return; }
			if (toSlideIndex < 0) { return; }
			
			/* check to run */
			if (toSlideIndex == self.slideIndex || !self.safeToAnimate) { return; }

			/* Check for phase out of overlay */
			if (typeof(self.options.slideData[self.slideIndex].overlay) != 'undefined') 
			{
				if (self.options.slideData[self.slideIndex].overlay.length > 0) 
					{ self.clearSlideOptions('out', self.slideIndex); }
			}
			
			self.safeToAnimate = false;
		
			/* set the new slide index */
			self.slideIndex = toSlideIndex;
			
			var slideIndex = self.slideIndex;
			var slideData = options.slideData;
			
			/* slide On Execute callback */
			$.isFunction(options.slideOnExecute) && options.slideOnExecute.call(self, slideIndex);

			// Set Active Indicators
			self.setIndicators();

			/* get reference to the top image */
			var topImagePath = options.rootImagePath+slideData[toSlideIndex].image;
			var lastActiveSlideIndex = ( self.lastActiveSlide == null) ? 0 : self.lastActiveSlide;
			var toSlide = self.galleryItems.eq(toSlideIndex);
			var fromSlide = self.galleryItems.eq(lastActiveSlideIndex);
			var toImage = toSlide.find("img");
			var toCurrSource = toImage.attr("src");
			var toFullSource = toImage.attr("longdesc");
			
   
			if (self.options.fullWidth) 											// create backround divs of the images
			{ 																								// add divs with backgrounds
				var toBackground = "url('"+toFullSource+"') no-repeat center center";
				var toDiv = self.galleryItems.eq(toSlideIndex);
				
				if (toCurrSource != toFullSource && toDiv.children("div").length == 0) 
				{																								// set the pre image to the full image
			        var newDiv = $('<div class="fullwidth-image"></div>');
			        toDiv.append(newDiv);
			        newDiv.css('background', toBackground);
			        newDiv.css('width', self.width);
			        newDiv.css('height', self.height);
			        newDiv.css('visibility', 'visible');
				}
			} else {
				if (toCurrSource != toFullSource) 							// set the preload image to the full image
					{ toImage.attr("src",toFullSource); }
			}
		
			// hide all slides except the active one to help with performance
			self.galleryItems.filter(":not(.activeitem)").css("display","none");
			fromSlide.css("display", "");

		   // bring new slide to the front
		   toSlide.css({"left":0,
		                "z-index":20,
		                "visibility":""});
		   // set the old slide behind this one
		   fromSlide.css({"z-index":10});
		   
		   // make sure visibility is turned on, because it may have been turned off on initial load for performance
		   toSlide.children('div.fullwidth-image').css("visibility", "");
		  
			if (animated)
			{    
    if (self.options.useCSS3)
    {
        // use CSS to animate
        // resets
        self.shiftSlides(); 
        self.safeToAnimate = false;
        var fadeDelay = (_ISMOBILE_) ? 250 : 0; // This is for iPad GPU preloading;
        toSlide.fadeTo(0, .01).delay(fadeDelay).fadeTo(0,.01, function() {
            // using the jquery fadeTo for making sure classes are added properly before initiating the rest of the fadein/fadeout to avoid glitches
            // animate the slide        
            fromSlide.css("left", 0);
            toSlide.css(_css3Property("transition", "opacity " + (options.transitionSpeed) + "ms ease-in-out"));
            toSlide.css({"display":"",             
                         "opacity": "1"
                         });
           
           // clean ups
            toSlide.bind('webkitTransitionEnd mozTransitionEnd oTransitionEnd transitionend msTransitionEnd', function()
            {
                toSlide.unbind();
                fromSlide.css({"display":"none", "z-index":""});
                toSlide.css(_css3Property("transition", "opacity " + (options.transitionSpeed) + "ms ease-in-out"));
                toSlide.css({"z-index":""});
                // slide complete callback
                $.isFunction(options.slideComplete) && options.slideComplete.call(self, self.slideIndex);
                // preload the next and previous slides if mobile
                if (_ISMOBILE_) {
                    var prevIndex = self.prevSlideIndex();
                    var nextIndex = self.nextSlideIndex();
                    self.galleryItems.eq(prevIndex).css("left", -self.width + 'px');
                    self.galleryItems.eq(nextIndex).css("left", self.width + 'px');
                    self.preloadCSSSlide(self.galleryItems.children().eq(prevIndex));
                    self.preloadCSSSlide(self.galleryItems.children().eq(nextIndex));
                }				
                // enable the arrows
                $(".mrmgallery-thumbnav div.mrmgallery-navarrowcontainer").removeClass('inactive');
                self.safeToAnimate = true;
               });
       });
    } else {
        // otherwise use JQuery to animate       
        toSlide.fadeTo(options.transitionSpeed, 1, function() 		// fade in new image - when complete
        {
            // slide complete callback
            $.isFunction(options.slideComplete) && options.slideComplete.call(self, self.slideIndex);
            toSlide.css("z-index","");// reset z-index
            fromSlide.css("z-index", "");
            self.shiftSlides();
            var prevIndex = self.prevSlideIndex();
            var nextIndex = self.nextSlideIndex();
            self.galleryItems.eq(prevIndex).css("left", -self.width + 'px');
            self.galleryItems.eq(nextIndex).css("left", self.width + 'px');
            // enable the arrows
            $(".mrmgallery-thumbnav div.mrmgallery-navarrowcontainer").removeClass('inactive');
        });
    }				
			} else {
        self.shiftSlides();
			}
   
			// Set the counts if used
			self.useHash = true;
			self.setPostProcessingOptions();
   
		},

			// -----------------------------------
		// -:- Sub Function: Wipe slides
		// -----------------------------------
  wipeToSlide: function(_toSlideIndex, _fromSlideIndex)
		{
			var self		= this;
			var options = self.options;
   
			if (self.num_slides == 1) { return; }
		
   // manage class naming
			if (!self.target.hasClass("wipeToSlide")) self.target.addClass("wipeToSlide");
			self.target.removeClass("fadeToSlide");
			self.target.removeClass("slide");
			   
			self.target.children(".galleryItem:not(.activeitem)").css("display", "none");
   
			// check for valid slide index 
			if (_toSlideIndex > self.num_slides-1) { return; }
			if (_toSlideIndex < 0) { return; }
			
			// check to run 
			if (_toSlideIndex == self.slideIndex || !self.safeToAnimate)	{ return; }

			// Check for phase out of overlay 
			if (typeof(self.options.slideData[self.slideIndex].overlay) != 'undefined') 
			{
				if (self.options.slideData[self.slideIndex].overlay.length > 0) 
					{ self.clearSlideOptions('out', self.slideIndex); }
			}
			
			self.safeToAnimate = false;

			// Safe to proceed, set the rest of the variables		
			var slideData = options.slideData;
			var _startpos = ( (_fromSlideIndex > _toSlideIndex) 
											? '-75%' 
											: '175%');
			var _finalpos = 0;
			
			self.slideIndex = _toSlideIndex;
			// Set Active Indicators
			self.setIndicators();
  
   // slide On Execute callback 
			$.isFunction(options.slideOnExecute) && options.slideOnExecute.call(self, _fromSlideIndex, _toSlideIndex);
   
   
			// get reference to the top image 
			var topImagePath = options.rootImagePath+slideData[_toSlideIndex].image;

			// get reference to the from slide
			var fromSlide = self.galleryItems.eq(_fromSlideIndex);
			var fromImage = fromSlide.find("img:first-child");
			var fromFade 	= fromSlide.find("span.gallery_fade");

			// get reference to the to slide
			var toSlide = self.galleryItems.eq(_toSlideIndex);
			var toImage = toSlide.find("img:first-child");
			var toFade 	= toSlide.find("span.gallery_fade");
			var nextSlide = self.galleryItems.eq(self.nextSlideIndex());

			var toCurrSource = toImage.attr("src");
			var toFullSource = toImage.attr("longdesc");
			
			if (self.options.fullWidth) 											// create backround divs of the images
			{ 																								// add divs with backgrounds
				var toBackground = "url('"+toFullSource+"') no-repeat center center";
				
				var toDiv = self.galleryItems.eq(_toSlideIndex);
				
				if (toCurrSource != toFullSource && toDiv.children("div").length == 0) 
				{																								// set the pre image to the full image
					var newDiv = $('<div class="fullwidth-image"></div>');
					toDiv.append(newDiv);
					newDiv.css('background', toBackground);
					newDiv.css('width', self.width);
					newDiv.css('height', self.height);
				}
				fromImage = fromSlide.find("div.fullwidth-image"); 
				toImage 	= toSlide.find("div.fullwidth-image"); 
			} else {
				if (toCurrSource != toFullSource) 							// set the preload image to the full image
				{ toImage.attr("src",toFullSource); }
			}

			
			// Prepare the fade to image
		   toFade.fadeTo(0, .01, function() {
		   toFade.css({'z-index':10, 'left':_startpos});			
		   toImage.css({'z-index':20, 'left':0, 'visibility':''}).hide();
   });
  
			// Prepare the fade from image
			fromImage.css({'z-index':20});
			fromFade.css({'z-index': 10, 'left':'50%'});
   
		   // reset parents
		   toImage.parent().css({'z-index': 20, 'display':'', 'visibility':''});
			fromImage.parent().css({'z-index': 10, 'display':''});
			
			// Begin animation fade out of current image
    
			// slide in progress callback
			$.isFunction(options.slideOnProgress) && options.slideOnProgress.call(self, _toSlideIndex);
    
    // do CSS animation
    if (self.options.useCSS3) {
        fromImage.fadeTo(0,1, function() {           
            // animate fadeTo
            var distance = (_toSlideIndex > _fromSlideIndex) ? -toFade.width() : toFade.width();
            // preload for GPU if mobile with a delay
            if (_ISMOBILE_) toFade.css("left", self.width-400+'px').fadeTo(0, .01).delay(250).css("left", self.width-1000+'px').fadeTo(0, .01);
            var animSpeed = (_ISMOBILE_) ? (options.transitionSpeed*1.25) : ((options.transitionSpeed)/2);
            var delayTime = (_ISMOBILE_) ? 500 : 0;
            toFade.delay(delayTime).show(function() {               
               toFade.css({"left":_startpos, "opacity": ""});
               toFade.css(_css3Property("transition", "BROWSERtransform " + (animSpeed) + "ms ease-in-out"));
               toFade.css(_css3Property("transform", "translate(" + distance + "px, 0px)"));                     
              }); 
            });
            
            // setup the 
             var resetObj = {
                "visibility": "",
                "opacity" : ".01",
                "left":""
                };
            toImage.css(resetObj);
            toImage.css(_css3Property("transition", "opacity 0s ease-in"));
                
            toFade.bind("webkitTransitionEnd mozTransitionEnd oTransitionEnd transitionend msTransitionEnd", function() {
                toFade.unbind();
                fromImage.css({'display':'none'});
                fromFade.css({'display':'none'});
                
                // set resets when the fade in is complete
                toImage.bind("webkitTransitionEnd transitionend mozTransitionEnd oTransitionEnd", function(){
                    toImage.unbind();
                    // do resets
                    fromImage.parent().css({'z-index': ''});
                        fromImage.css({'z-index': '', 'opacity':'', 'display': ''});
                        fromImage.css(_css3Property("transition", ""));
                        fromFade.css({'z-index': '','left':'', 'display':'none'});
                        toFade.css({'z-index': '',
                                    'left':'',
                                    'opacity':''
                                    });
                        toFade.css(_css3Property("transition", ""));
                        toFade.css(_css3Property("transform", ""));
                        toImage.css({'z-index':''});
                        // preload the next slide
                        nextSlide.css({'z-index':1, 'visibility':''});
                        // slide complete callback
                        $.isFunction(options.slideComplete) && options.slideComplete.call(self, self.slideIndex);
                        // preload the wipes for the GPU
                        var prevIndex = self.prevSlideIndex();
                        var nextIndex = self.nextSlideIndex();
                        var prevFaderSlide = self.galleryItems.eq(prevIndex).children("span.gallery_fade");
                        var nextFaderSlide = self.galleryItems.eq(nextIndex).children("span.gallery_fade");
                        self.useHash = true;
                        self.shiftSlides();
                         // enable the arrows
                        $(".mrmgallery-thumbnav div.mrmgallery-navarrowcontainer").removeClass('inactive');
                });
                
                // fadein toImage
                toImage.css({"left":"0px", "visibility":'', 'display':''}); 
                toImage.fadeTo(0, .01).delay(500).fadeTo(0,.01, function() {
                    var animSpeed = (_ISMOBILE_) ? (options.transitionSpeed*1.25) : ((options.transitionSpeed)/2);
                    if (_ISMOBILE_) animSpeed = (animSpeed/4);
                    toImage.css(_css3Property("transition", "opacity " + animSpeed + "ms" + " ease-in"));
                    toImage.css({"opacity": "1"});
                });
                
            });
            toImage.css({"left":"0px", "visibility":'', 'display':''});            
        
    } else
    {
         // do jQuery animation
        
            // fade out fromImage
            fromImage.fadeTo((self.options.transitionSpeed / 4), 0);
            // animate fadeTo
            toFade.fadeTo(0, 1).animate(
            {left: '50%'}, 
            {
             duration: (self.options.transitionSpeed), 
             easing: 	self.options.easing
            }
           );
          // animate toImage
         	toImage.delay((self.options.transitionSpeed / 2)).fadeTo( (self.options.transitionSpeed / 2), 1, function () 
            {
             fromImage.parent().css({'z-index': ''});
             fromImage.css({'z-index': ''});
             fromFade.css({'z-index': ''});
             toFade.css({'z-index': ''});
             toImage.css({'z-index':''});
             self.useHash = true;
             self.shiftSlides();
             // slide complete callback
             $.isFunction(options.slideComplete) && options.slideComplete.call(self, self.slideIndex);
				
            // enable the arrows
            $(".mrmgallery-thumbnav div.mrmgallery-navarrowcontainer").removeClass('inactive');
            });
    }
    
		
			
		
  },
		/* -----------------------------------
		// -- Sub Function: Goto a specific slide
		//		(OLD) Will always use the cross fade
		//		(NEW) Check for transition mode
		// -----------------------------------*/
		goToSlide : function(slideIndex, animated) 
		{

			var self 				= this;
			var options 		= self.options;
			var _fromslide 	= self.slideIndex;		
			
			// check for animated argument
			(typeof(animated) == 'undefined') ? animated = true : null;
			if (self.num_slides == 1) 
				{ return; }

//			self.resetSocialOptions(slideIndex);
			if (self.safeToAnimate) 
			{
				// kill video if playing
				$(self.options.videoArea).empty();
				// preload slide
				self.preloadImage(slideIndex, function() {
					switch (options.transitionMode)
					{
						case 'fade':		
						case 'slide':		self.fadeToSlide(slideIndex, animated)	;	break;
						case 'slideAll':	self.slide(slideIndex);	break;
						case 'wipe':		self.wipeToSlide(slideIndex, _fromslide);	break;
					}
				});
			}
		},
	
		// ===========================================================================
		// == Area: Transitions Finish 
		// ===========================================================================
	
		/* -----------------------------------
		// -- Sub Function: Create the event listeners
		// ----------------------------------- */
		createEventListeners : function() 
		{
			var self = this;
			var options = self.options;
			var slideIndex = self.slideIndex;
			var slideData = options.slideData;

			// General Hover
			if (!_ISMOBILE_)
			{
				self.target.hover(
					function() 
					{ 
				  	self.target.find('div.mg_share').stop().show().fadeTo(200, 1); 
				  	self.target.find('div.mrmgallery-arrow').stop().show().fadeTo(200, 1); 
						if (self.target.find(".mrmgallery-desc").length > 0) 
							{ self.target.find(".mrmgallery-desc").fadeTo('slow', 0.6); }
					},
					function() 
					{ 
				  	self.target.find('div.mg_share').stop().fadeTo(200, 0).hide(); 
				  	self.target.find('div.mrmgallery-arrow').stop().fadeTo(200, 0).hide(); 
						if (self.target.find(".mrmgallery-desc").length > 0) 
							{ self.target.find(".mrmgallery-desc").fadeOut('fast'); }
					}
				); 
			} else {
				
				if (self.target.find(".mrmgallery-desc").length > 0) 
						{ self.target.find(".mrmgallery-desc").fadeTo('slow', 0.6).css({'z-index':1000}); }
				self.target.find('div.mrmgallery-arrow').stop().show();		
			}

			// Check for Thumbnail Selectors
			if (self.thumbsObj.length > 0)
			{
				self.thumbsObj.find("li a").live(_MOVEMENTS_.click, function(e) 
				{
					var index = $(this).parent().index();

					// if the same index, or not animation safe, just return
					if (index == self.slideIndex || !self.safeToAnimate) 
						{ return; }
					self.goToSlide(index, true);
					
					window.shareimage = self.options.slideData[index].image;
					e.preventDefault();
				});

				
				// Mini Arrows on thumbnails
				if (self.options.enableThumbSlide) 
				{
					var thumbSlide = $(".mrmgallery-thumbnav div.mrmgallery-navarrowcontainer");
					thumbSlide.live('click', function(e) 
					{		
						if ($(this).hasClass('inactive'))
							return;						
						
						// disable the arrows
						thumbSlide.addClass('inactive');
						
						// get the arrow we clicked on
						var _clicked = $(this).children('div.mrmgallery-navarrow');
						
						// this flag is used to indicate if we are wrapping around
						var wrappedAround = false;
						
						if ( _clicked.hasClass('prev')) // prev arrow clicked
						{
							self.options.ts_curpos += self.options.ts_movewidth;
							
							if (self.options.ts_curpos > 0)
							{
								self.options.ts_curpos = -(self.options.ts_movewidth * (self.num_slides - self.options.thumbsToShow));
								wrappedAround = true;
							}
							
							function prevAnimationDoneCallback()							
							{
								// check if the current item is in view									
								var currentItemPosition = -self.slideIndex * self.options.ts_movewidth;
								var startPosition = self.options.ts_curpos;
								var endPosition = self.options.ts_curpos - (self.options.thumbsToShow * self.options.ts_movewidth);
								
								if (!(startPosition >= currentItemPosition && currentItemPosition > endPosition))
								{								
									// if we wrapped around and current item not intor view
									if (wrappedAround)
									{
										self.goToSlide(self.num_slides - 1, true);
									}
									else
									{
										self.prevSlide();
									}								
								}
								else
								{
									// done enable arrows								
									thumbSlide.removeClass('inactive');								
								}
							}
							
							if (self.options.useCSS3)
							{
								// perform the slide animation								
								self.thumbsObj.bind("webkitTransitionEnd mozTransitionEnd oTransitionEnd transitionend msTransitionEnd", function() {
									self.thumbsObj.unbind(); // unbind the event									
									prevAnimationDoneCallback(); // call the animation done callback
								});
								
								self.thumbsObj.css(_css3Property("transform", "translate(" + self.options.ts_curpos + "px, 0px)"));
								self.thumbsObj.css(_css3Property("transition", "BROWSERtransform 0.3s ease-out"));								
							}
							else
							{							
								self.thumbsObj.stop().animate({left: self.options.ts_curpos}, 300, prevAnimationDoneCallback());
							}
						}
						else if ( _clicked.hasClass('next')) // next arrow clicked
						{							
							self.options.ts_curpos -= self.options.ts_movewidth;							
							
							if(self.options.ts_curpos < -self.options.ts_maxleft)							
							{
								self.options.ts_curpos = 0;
								wrappedAround = true;
							}
							
							function nextAnimationDoneCallback()							
							{
								var currentItemPosition = -self.slideIndex * self.options.ts_movewidth;
								var startPosition = self.options.ts_curpos;
								var endPosition = self.options.ts_curpos - (self.options.thumbsToShow * self.options.ts_movewidth);
								
								if (!(startPosition >= currentItemPosition && currentItemPosition >= endPosition))
								{
									if (wrappedAround)	
									{ 
										self.goToSlide(0, true);
									}
									else 
									{ 
										self.nextSlide(); 
									}									
								}
								else { thumbSlide.removeClass('inactive');}// done enable arrows								
							}
							
							// browser supports css 3 transforms and animations
							if (self.options.useCSS3)
							{								
								// perform the slide animation								
								self.thumbsObj.bind("webkitTransitionEnd mozTransitionEnd oTransitionEnd transitionend msTransitionEnd", function() {
									self.thumbsObj.unbind(); // unbind the event									
									nextAnimationDoneCallback(); // call the animation done callback
								});
								
								self.thumbsObj.css(_css3Property("transform", "translate(" + self.options.ts_curpos + "px, 0px)"));
								self.thumbsObj.css(_css3Property("transition", "BROWSERtransform 0.3s ease-out"));							
							}
							else
							{	
								self.thumbsObj.stop().animate({left: self.options.ts_curpos}, 300, nextAnimationDoneCallback()); 
							}
							
						}
						else // not a valid command ... enable the arrows
						{
							thumbSlide.removeClass('inactive'); 
						}
					});
				}
	
			}
			
			// Check for Tab Selectors
			if (self.options.tabsSelector)
			{ 
				$(self.options.tabsSelector+" li a").live(_MOVEMENTS_.click, function(e) 
				{
					var index = $(this).parent().index();
					// if the same index, or not animation safe, just return
					if (index == self.slideIndex || !self.safeToAnimate) 
						{ return; }
					$(self.options.tabsSelector+" li."+ self.options.activeID).removeClass(self.options.activeID);
					self.target.addClass(self.options.activeID);
					self.goToSlide(index, true);
					window.shareimage = self.options.slideData[index].image;
					e.preventDefault();
				});
			}
			
			// Check for Dot Selectors
			if (self.dotsObj.length > 0)
			{ 
				self.dotsObj.find("li a").live(_MOVEMENTS_.click, function(e) 
				{
					var index = $(this).parent().index();
					// if the same index, or not animation safe, just return
					if (index == self.slideIndex || !self.safeToAnimate) 
					{ 
						return; 
					} 
					self.dotsObj.find("li."+ self.options.activeID).removeClass(self.options.activeID);
					self.target.addClass(self.options.activeID);
					self.goToSlide(index, true);
				     try {
				        window.shareimage = self.options.slideData[index].image; 
				     } catch (err) {}
					
					e.preventDefault();
				});
			}
			
			// Check for arrows 
			if (self.target.find('div.mrmgallery-arrow').length > 0) 
			{ 	
				var allArrows = self.target.find('div.mrmgallery-arrow');
				var nextArrow = self.target.find('div.mrmgallery-arrow.next');
				var prevArrow = self.target.find('div.mrmgallery-arrow.prev');				
				
				// Arrow Prev Click Event				
				prevArrow.live(_MOVEMENTS_.click, function(e) 
				{			
					e.preventDefault();
					if (self.safeToAnimate) {
						self.prevSlide();
						var slideIndex = self.slideIndex;
						self.setMainHashTag();
						window.shareimage = self.options.slideData[slideIndex].image;
						
						
						// check if items is into view
						var currentItemPosition = -self.slideIndex * self.options.ts_movewidth;
						var startPosition = self.options.ts_curpos;
						var endPosition = self.options.ts_curpos - (self.options.thumbsToShow * self.options.ts_movewidth); 
							
						if (!(startPosition >= currentItemPosition && currentItemPosition > endPosition))
						{
							self.options.ts_curpos += self.options.ts_movewidth;
							
							if (self.options.ts_curpos > 0)
							{
								self.options.ts_curpos = -(self.options.ts_movewidth * (self.num_slides - self.options.thumbsToShow));							
							}
							if (self.thumbsObj.length > 0) {
								if (self.options.useCSS3)
								{							
										
									self.thumbsObj.css(_css3Property("transform", "translate(" + self.options.ts_curpos + "px, 0px)"));
									self.thumbsObj.css(_css3Property("transition", 'BROWSERtransform 0.3s ease-out'));		
								}
								else
								{
									self.thumbsObj.stop().animate({left: self.options.ts_curpos}, 300);	
								}
							}
						}
					}					
				});
				
				// Arrow Next Click Event
				nextArrow.live(_MOVEMENTS_.click, function(e) 
				{
					e.preventDefault();
					if (self.safeToAnimate) {						
						self.nextSlide();
						
						var slideIndex = self.slideIndex;					
						self.setMainHashTag();
						window.shareimage = self.options.slideData[slideIndex].image;
						
						// check if items is into view
						var currentItemPosition = -self.slideIndex * self.options.ts_movewidth;
						var startPosition = self.options.ts_curpos;
						var endPosition = self.options.ts_curpos - (self.options.thumbsToShow * self.options.ts_movewidth); 
						
						if (!(startPosition > currentItemPosition && currentItemPosition > endPosition))
						{
							// slide one slide over to keep the current item under view
							self.options.ts_curpos -= self.options.ts_movewidth;
							
							if(self.options.ts_curpos < -self.options.ts_maxleft)							
							{
								self.options.ts_curpos = 0;
							}
							if (self.thumbsObj.length > 0) {
								if (self.options.useCSS3)
								{							
									self.thumbsObj.css(_css3Property("transform", "translate(" + self.options.ts_curpos + "px, 0px)"));
									self.thumbsObj.css(_css3Property("transition", 'BROWSERtransform 0.3s ease-out'));		
								}
								else
								{
									self.thumbsObj.stop().animate({left: self.options.ts_curpos}, 300);	
								}		
							}
						}
					}
				});
				
				// Arrow Fade Events
				if (self.options.fadeArrows) 
				{ 
					$("div.my-mrmgallery").hover(
						function() 
						{ 
							allArrows.stop(true, true).fadeIn(500); 
							$(".mg_share").stop(true, true).fadeIn(500); 
						},
						function() 
						{ 
							allArrows.stop(true, true).fadeOut(500); 
							$(".mg_share").stop(true, true).fadeOut(500); 
							prevArrow.find("a div.slide").width(0);
							nextArrow.find("a div.slide").width(0);
						}
					);
				}
						
				/* -- Check for Thumbnails and Counts on Arrows */
				if ((self.options.thumbsOnArrows)  || (self.options.countOnArrows))
				{ 
					var slidePrev 	= self.prevSlideIndex();
					var slideIndex 	= self.slideIndex;
					var slideNext 	= self.nextSlideIndex();

					/* Right (Next) Arrow */
					nextArrow.live(_MOVEMENTS_.mouseover + ' mouseout', function(event) {
						var _right = 84;
						var _width = 0;
					  if ((event.type == 'mouseover') || (event.type == 'tap'))
					  {
							if (self.options.thumbsOnArrows) 
								{ _width += self.options.spriteWidth; }
								
							if (self.options.countOnArrows)
								{ _width += 55; }
							nextArrow.find("a div.slide").stop().animate({right: _right +"px", width:_width}, 300);
					  } else {
							_width = 0;
							nextArrow.find("a div.slide").stop().animate({right: _right + "px", width:_width}, 300);
			  		}
					});

					/* Left (Prev) Arrow */
					prevArrow.live(_MOVEMENTS_.mouseover+' mouseout', function(event) {
						var _left = 84;
						var _width = 0;
					  if ((event.type == 'mouseover')  || (event.type == 'tap'))
					  {
							if (self.options.thumbsOnArrows) 
								{ _width += self.options.spriteWidth; }
								
							if (self.options.countOnArrows)
								{ _width += 55; }
							prevArrow.find("a div.slide").stop().animate({left: _left +"px", width:_width}, 300);
					  } else {
							_width = 0;
							prevArrow.find("a div.slide").stop().animate({left: _left + "px", width:_width}, 300);
			  		}
					});					
				}
			}
			
			/* tool tips */
			if (self.options.enableTooltips)
			{
				$(self.options.thumbsSelector+" li a img").live(_MOVEMENTS_.mouseover+' mouseout mousemove', function(e) 
				{
					if ((e.type == 'mouseover') || (e.type == 'tap'))
					{
						var titleText = $(this).attr('tooltip');
						if ( (typeof $(this).attr('tooltip') == 'undefined') || (titleText == '') || (titleText == 'undefined') )
							{ titleText = $(this).attr('title'); }
						
						if ($(this).data('tipText') != null)
						{
							$(this)
								.data('tipText', titleText);
						}
						$(	'<p class="mrmgallery-tooltip">'
							+		'<span class="tt_text">'
							+			titleText
							+		'</span>'
							+		'<span class="tt_caret"></span>'
							+	'</p>')
							.appendTo('body')
							.css('top', (e.pageY - 45) + 'px')
							.css('left', (e.pageX - 40) + 'px')
							.delay(500)
							.fadeIn('slow');
					} else if (e.type == 'mouseout') {
						// Hover out code
						$('.mrmgallery-tooltip').remove();
					} else if (e.type == 'mousemove') {
						$('.mrmgallery-tooltip')
							.css('top', (e.pageY - 45) + 'px')
							.css('left', (e.pageX - 40) + 'px');
					}
				});
			}
   	/* Swipe captures */
    if (_ISMOBILE_ && self.options.enableSwipe) { 
        self.target.bind("touchstart", function(e) {
        	if (self.safeToAnimate) {
	             var touch = e.originalEvent.touches[0] || e.originalEvent.changedTouches[0];
	             _TOUCHES_.startX = touch.pageX;
	             _TOUCHES_.startY = touch.pageY;
	             _TOUCHES_.hasSwiped = false;	           
        	} else {
        		e.preventDefault();
        	}
        });
        self.target.bind("touchmove", function(e){ 
        	
            if (!_TOUCHES_.hasSwiped && self.safeToAnimate) {             	
            	 var touch = e.originalEvent.touches[0] || e.originalEvent.changedTouches[0];
                 _TOUCHES_.lastX = touch.pageX;
                 _TOUCHES_.lastY = touch.pageY;
                 var touchDistanceX = _TOUCHES_.startX - _TOUCHES_.lastX;
                 var touchDistanceY = _TOUCHES_.startY - _TOUCHES_.lastY;
                 
         
                 if (touchDistanceX <= -50) {
                    e.preventDefault();
                    self.slide('prev');
                    _TOUCHES_.hasSwiped = true;
                    
                    // hashtags
                    var slideIndex = self.slideIndex;
                    self.setMainHashTag();
                    window.shareimage = self.options.slideData[slideIndex].image;            
                    
                    // check if items is into view
                    var currentItemPosition = -self.slideIndex * self.options.ts_movewidth;
                    var startPosition = self.options.ts_curpos;
                    var endPosition = self.options.ts_curpos - (self.options.thumbsToShow * self.options.ts_movewidth); 
                    
                    if (!(startPosition >= currentItemPosition && currentItemPosition > endPosition))
                    {
                     self.options.ts_curpos += self.options.ts_movewidth;
                     
                     if (self.options.ts_curpos > 0)
                     {
                      self.options.ts_curpos = -(self.options.ts_movewidth * (self.num_slides - self.options.thumbsToShow));							
                     }
                     if (self.thumbsObj.length > 0) {
	                     if (self.options.useCSS3)
	                     {							
	                      
	                    	 self.thumbsObj.css(_css3Property("transform", "translate(" + self.options.ts_curpos + "px, 0px)"));
	                    	 self.thumbsObj.css(_css3Property("transition", 'BROWSERtransform 0.3s ease-out'));		
	                     }
	                     else
	                     {
	                    	 self.thumbsObj.stop().animate({left: self.options.ts_curpos}, 300);	
	                     }
                     }
                    }
                } else if (touchDistanceX >= 50) {
                    e.preventDefault();              
                    _TOUCHES_.hasSwiped = true;
                    self.slide('next');
                   
                   // hashtags
                    var slideIndex = self.slideIndex;
                    self.setMainHashTag();
                    window.shareimage = self.options.slideData[slideIndex].image;
                    
                    
                    // check if items is into view
                    var currentItemPosition = -self.slideIndex * self.options.ts_movewidth;
                    var startPosition = self.options.ts_curpos;
                    var endPosition = self.options.ts_curpos - (self.options.thumbsToShow * self.options.ts_movewidth); 
                    
                    if (!(startPosition > currentItemPosition && currentItemPosition > endPosition))
                    {
                     // slide one slide over to keep the current item under view
                     self.options.ts_curpos -= self.options.ts_movewidth;
                     
                     if(self.options.ts_curpos < -self.options.ts_maxleft)							
                     {
                      self.options.ts_curpos = 0;
                     }
                     if (self.thumbsObj.length > 0) {
	                     if (self.options.useCSS3)
	                     {							
	                    	 self.thumbsObj.css(_css3Property("transform", "translate(" + self.options.ts_curpos + "px, 0px)"));
	                    	 self.thumbsObj.css(_css3Property("transition", 'BROWSERtransform 0.3s ease-out'));		
	                     }
	                     else
	                     {
	                    	 self.thumbsObj.stop().animate({left: self.options.ts_curpos}, 300);	
	                     }
                     }
                    }
                 }   
             }
        });
    }
  
  
  	/* Keyboard captures */
   
   // Check for this instance is disabled
   
			if (self.options.enableKeyboard)
			{
				$(document).keydown(function(e)
				{
        if (e.keyCode == 37 && self.safeToAnimate && self.options.kbdisable == 0) 
        {
            e.preventDefault();
            self.prevSlide();
            var slideIndex = self.slideIndex;
            self.setMainHashTag();
            window.shareimage = self.options.slideData[slideIndex].image;            
            
            // check if items is into view
            var currentItemPosition = -self.slideIndex * self.options.ts_movewidth;
            var startPosition = self.options.ts_curpos;
            var endPosition = self.options.ts_curpos - (self.options.thumbsToShow * self.options.ts_movewidth); 
            
            if (!(startPosition >= currentItemPosition && currentItemPosition > endPosition))
            {
             self.options.ts_curpos += self.options.ts_movewidth;
             
             if (self.options.ts_curpos > 0)
             {
              self.options.ts_curpos = -(self.options.ts_movewidth * (self.num_slides - self.options.thumbsToShow));							
             }
             if (self.thumbsObj.length > 0) {
	             if (self.options.useCSS3)
	             {							
	              
	            	 self.thumbsObj.css(_css3Property("transform", "translate(" + self.options.ts_curpos + "px, 0px)"));
	            	 self.thumbsObj.css(_css3Property("transition", 'BROWSERtransform 0.3s ease-out'));		
	             }
	             else
	             {
	            	 self.thumbsObj.stop().animate({left: self.options.ts_curpos}, 300);	
	             }		
             }
         }
         
         return false;
        } else if (e.keyCode == 39 && self.safeToAnimate && self.options.kbdisable == 0) {
            e.preventDefault();
         self.nextSlide();
         var slideIndex = self.slideIndex;
         self.setMainHashTag();
         window.shareimage = self.options.slideData[slideIndex].image;
         
         
         // check if items is into view
         var currentItemPosition = -self.slideIndex * self.options.ts_movewidth;
         var startPosition = self.options.ts_curpos;
         var endPosition = self.options.ts_curpos - (self.options.thumbsToShow * self.options.ts_movewidth); 
         
         if (!(startPosition > currentItemPosition && currentItemPosition > endPosition))
         {
          // slide one slide over to keep the current item under view
          self.options.ts_curpos -= self.options.ts_movewidth;
          
          if(self.options.ts_curpos < -self.options.ts_maxleft)							
          {
           self.options.ts_curpos = 0;
          }
          if (self.thumbsObj.length > 0) {
	          if (self.options.useCSS3)
	          {							
	        	  self.thumbsObj.css(_css3Property("transform", "translate(" + self.options.ts_curpos + "px, 0px)"));
	        	  self.thumbsObj.css(_css3Property("transition", 'BROWSERtransform 0.3s ease-out'));		
	          }
	          else
	          {
	        	  self.thumbsObj.stop().animate({left: self.options.ts_curpos}, 300);	
	          }			
          }
         }
         
         return false;
        }
    });
			}
			
			/* Resize window */
			$(window).resize(function() 
			{
				self.width = self.target.width();
				self.shiftLefts();
				self.target.children(".galleryItem").css("width", self.width+"px");
				if (self.options.fullWidth) 
					{ self.target.find(".fullwidth-image").css("width", self.width+"px"); }
			});
		
		},
	
		/* -----------------------------------
		// -- Sub Function: Return the slide index (Previous)
		// -----------------------------------*/
		prevSlideIndex : function() 
		{
			var self = this;
			if (self.num_slides == 1) 
				{ return -1; }
			var slideIndex = self.slideIndex;
			return ( (slideIndex > 0) ? slideIndex-1 : self.num_slides-1);
		},
	
		/* -----------------------------------
		// -- Sub Function: Return the slide index (Next)
		// -----------------------------------*/
		nextSlideIndex : function() 
		{
			var self = this;
			if (self.num_slides == 1) 
				{ return -1; }
			var slideIndex = self.slideIndex;
			return ( (slideIndex < self.num_slides-1) ? slideIndex+1 : 0 ) ;
		},
	
		/* -----------------------------------
		// -- Sub Function: Return the slide index (Current)
		// ----------------------------------- */
		currentSlideIndex : function() 
		{
			return this.slideIndex;
		},
		
		// ===========================================================================
		// == Area: Begin Private Functions
		// ===========================================================================
		/* -----------------------------------
		// -- Function: Set Active Indicator
		// ----------------------------------- */
		setIndicators : function()
		{
			var self = this;
			var options = self.options;
			var slideIndex = self.slideIndex;
			var slideData = options.slideData;

			// set description for slide 
			
			if (typeof(self.options.slideData[slideIndex].description) != 'undefined')
			{ 
				self.target.children("div.mrmgallery-desc").html('<blockquote>'
					+		'<span>'
					+			self.options.slideData[slideIndex].description
					+		'</span>'
					+	'</blockquote>'); 
			}
			
			if (self.thumbsObj.length > 0) 
			{
				self.thumbsObj.find("li."+ self.options.activeID).removeClass(self.options.activeID);
				self.thumbsObj.find("li:eq("+slideIndex+")").addClass(self.options.activeID);
			}
			 
			if (self.options.tabsSelector) 
			{
				$(self.options.tabsSelector+" li."+ self.options.activeID).removeClass(self.options.activeID);
				$(self.options.tabsSelector+" li:eq("+slideIndex+")").addClass(self.options.activeID);
			}
			if (self.dotsObj.length > 0) 
			{
				self.dotsObj.find("li."+ self.options.activeID).removeClass(self.options.activeID);
				self.dotsObj.find("li:eq("+slideIndex+")").addClass(self.options.activeID);
			}
			if (self.useHash) self.setMainHashTag(slideIndex);
		},
		// -----------------------------------
		// -- Function: setMainHashTag
		// -----------------------------------
		setMainHashTag: function(slideIndex) {
		    	// set hash tags
		    if (slideIndex == null) slideIndex = this.currentSlideIndex();
		    var hash = this.target.children().eq(slideIndex).children(".hash-id").text();
		    var currentHash = window.location.hash;
		    if (hash.length > 0) window.location.hash = escape(hash.toLowerCase());
		},
		// -----------------------------------
		// -- Function: Check Social Text 
		// -----------------------------------
		_checkSocial : function(_self, _obj, _imgData, _type)
		{
			_imgData.social[_type]	= new Array;
						// ('message', 'title', 'caption', 'description','thumbnail' );

			/* Check for the share message */
			if ( $(_obj).children("span.social").children("span.share-message."+_type).html() != null)
				{ _imgData.social[_type]['message'] = $(_obj).children("span.social").children("span.share-message."+_type).html(); }

			/* Check for the share title */
			if ( $(_obj).children("span.social").children("span.share-title."+_type).html() != null)
				{_imgData.social[_type]['title'] = $(_obj).children("span.social").children("span.share-title."+_type).html(); }
					
			/* Check for the share caption */
			if ( $(_obj).children("span.social").children("span.share-caption."+_type).html() != null)
				{ _imgData.social[_type]['caption'] = $(_obj).children("span.social").children("span.share-caption."+_type).html(); }

			/* Check for the share description */
			if ( $(_obj).children("span.social").children("span.share-description."+_type).html() != null)
				{ _imgData.social[_type]['description'] = $(_obj).children("span.social").children("span.share-description."+_type).html(); }

			/* Check for the share thumbnail */
			if ( $(_obj).children("span.social").children("span.share-thumbnail."+_type).html() != null)
				{ _imgData.social[_type]['thumbnail'] = $(_obj).children("span.social").children("span.share-thumbnail."+_type).html(); }
		},

		// -----------------------------------
		// -- Function: Return Social Text
		// -----------------------------------
		getSocial : function(_self, _slideData, _type)
		{

			var _returntext = new Array('message', 'title', 'caption', 'description','thumbnail' );
			
			// First prepopulate the defaults
			_returntext['message'			] =	(_slideData['default']['message'			] || "");
			_returntext['title'				] =	(_slideData['default']['title'				] || "");
			_returntext['caption'			] =	(_slideData['default']['caption'			] || "");
			_returntext['description'	] =	(_slideData['default']['description'	] || "");
			_returntext['thumbnail'		] =	(_slideData['default']['thumbnail'		] || "");
			_returntext['download'		] =	(_slideData['default']['download'			] || "");
			
			/* Check for the share message */
			if (	(_slideData[_type]['message'] != '') && (typeof(_slideData[_type]['message']) != 'undefined' ))
				{ _returntext['message'] =	_slideData[_type]['message'];  }

			/* Check for the share title */
			if (	(_slideData[_type]['title'] != '') && (typeof(_slideData[_type]['title']) != 'undefined' ))
				{ _returntext['title'] =	_slideData[_type]['title'];  }
					
			/* Check for the share caption */
			if (	(_slideData[_type]['caption'] != '') && (typeof(_slideData[_type]['caption']) != 'undefined' ))
				{ _returntext['caption'] =	_slideData[_type]['caption'];  }

			/* Check for the share description */
			if (	(_slideData[_type]['description'] != '') && (typeof(_slideData[_type]['description']) != 'undefined' ))
				{ _returntext['description'] =	_slideData[_type]['description'];  }

			/* Check for the share thumbnail */
			if (	(_slideData[_type]['thumbnail'] != '') && (typeof(_slideData[_type]['thumbnail']) != 'undefined' ))
				{ _returntext['thumbnail'] =	_slideData[_type]['thumbnail'];  }

			return _returntext;			

		},
		
		/* -----------------------------------
		// -- Function: Refresh the Cufon Replaces
		// ----------------------------------- */
		cufonRefresh: function()
		{
			var self = this;

			// Check if there are items in the option to replace
			if (self.options.cufonRefresh.length)
			{
				Cufon.refresh(self.options.cufonRefresh);
			}
			
		},	
		
		// -----------------------------------
		// -- Function: Execute Tracking
		//	ToDo: Add all required tracking items
		// -----------------------------------
		executeTracking: function(_trackitem, _slideData, _trackData)
		{
			s.pageName	= ( (_trackData[ 0] != '') ? _trackData[ 0] : ''); 
			s.prop1			= ( (_trackData[ 1] != '') ? _trackData[ 1] : ''); 
			s.prop2			= ( (_trackData[ 2] != '') ? _trackData[ 2] : ''); 
			s.prop3			= ( (_trackData[ 3] != '') ? _trackData[ 3] : ''); 
			s.prop4			= ( (_trackData[ 4] != '') ? _trackData[ 4] : ''); 
			s.prop5			= ( (_trackData[ 5] != '') ? _trackData[ 5] : ''); 
			s.prop6			= ( (_trackData[ 6] != '') ? _trackData[ 6] : ''); 
			s.prop7			= ( (_trackData[ 7] != '') ? _trackData[ 7] : ''); 
			s.prop8			= ( (_trackData[ 8] != '') ? _trackData[ 8] : ''); 
			s.prop9			= ( (_trackData[ 9] != '') ? _trackData[ 9] : ''); 
			s.prop10		= ( (_trackData[10] != '') ? _trackData[10] : ''); 
			s.t();
		},	
		
		// ===========================================================================
		// == Area: Finish Private Functions
		// ===========================================================================
		// ===========================================================================
		// == Area: Begin Externally Used Functions
		// ===========================================================================
		/* -----------------------------------
		// -- Gallery - Disable Keyboard Functions
		// ----------------------------------- */
		disableKeyboard : function(_disabled)
		{
			var self = this;

			if (self.options.enableKeyboard == false) { return false; }
			this.options.kbdisable = _disabled;
		}
	}; // End MRMGallery Object


	/* -----------------------------------
	// -- Gallery - Options
	// ----------------------------------- */
	$.mrmgallery.options = function (options) 
		{ $.extend( this, $.mrmgallery.options, options ); };

	$.mrmgallery.options.prototype = _defaultOptions;

	// expose as a selector plugin
	$.fn.mrmgallery = function (options) 
	{
		return this.each(function() 
			{ new $.mrmgallery(this, options); });
	};
	
})(jQuery);

// ===========================================================================
// == Area: Global Functions
// ===========================================================================
  /* -----------------------------------
		// -- CSS3 Property - Helper function puts proper prefixes for CSS3 specific properties
		// ----------------------------------- */
  function _css3Property(property, value) {
    var browserTypes = ["-webkit-", "-moz-", "-o-", "-ms-", ""];
    value = String(value);
    var arr = [];
    for (i=0;i<browserTypes.length;i++) {
        // check if the value is actually an array for special processing
        if (value.startsWith("translate") && _TRANSLATE3D_) {
                value = value.replace("translate", "translate3d");
                value = value.replace(")", ", 0px)");
        }        
        arr.push("'" + browserTypes[i] + property + "':'" + value.replace('BROWSER', browserTypes[i]) + "'");
    }
    eval("var obj = {" + arr.join(", ") + "};");
    return obj;
  };
  /* -----------------------------------
		// -- Starts With Extension - Adds the method 'startsWith' to the String object for matching the beginning of a string
		// ----------------------------------- */
  String.prototype.startsWith = function(str)
    {return (this.match("^"+str)==str);}