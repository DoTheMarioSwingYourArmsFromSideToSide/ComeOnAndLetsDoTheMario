var isChatReadyOn= true;
var paramsToAdd =  "";
var flashStatus = 0;

// DEPRECIATED
function agents_available(accountId, departmentId) {
	if($_("#smartbutton").length > 0){ 
        var sb = $_("#smartbutton"); 
		var innerhtml = '<a href="#" id="chatBtn" title="Live Now" onclick="openPopUp(true, ' + accountId + ',' + departmentId + ');return false;">Live Chat</a><a href="#" id="chatClose" onclick="closeChat();return false;" title="Close">Close Live Chat</a>';
		sb.html(innerhtml);
	}
	
	if($_(".smartbutton").length > 0){ 
		var sb = $_(".smartbutton"); 
		var innerhtml = '<a href="#" id="chatBtn" title="Live Now" onclick="openPopUp(true, ' + accountId + ',' + departmentId + ');return false;">Live Chat</a><a href="#" id="chatClose" onclick="closeChat();return false;" title="Close">Close Live Chat</a>';
		sb.html(innerhtml);
	}
	
    paramsToAdd = accountId + "','" + departmentId;
    isChatReadyOn = true;
    return true;
}

// DEPRECIATED
function agents_not_available(accountId, departmentId) {
	if($_("#smartbutton").length > 0){ 
        var sb = $_("#smartbutton");
		var innerhtml = '<a href="#" id="chatBtn" title="Live Now" onclick="openPopUp(true, ' + accountId + ',' + departmentId + ');return false;">Live Chat</a><a href="#" id="chatClose" onclick="closeChat();return false;" title="Close">Close Live Chat</a>';
		sb.html(innerhtml);
	}
	
	if($_(".smartbutton").length > 0){ 
		var sb = $_(".smartbutton");
		var innerhtml = '<a href="#" id="chatBtn" title="Live Now" onclick="openPopUp(true, ' + accountId + ',' + departmentId + ');return false;">Live Chat</a><a href="#" id="chatClose" onclick="closeChat();return false;" title="Close">Close Live Chat</a>';
		sb.html(innerhtml);
	}
	
    paramsToAdd = accountId + "','" + departmentId;
    isChatReadyOn = false;
    return true;
}

// this will close the chat box on page (not for popup)
function closeChat() {
	if($_("#smartbutton").length > 0){
		$_('#smartbutton').fadeOut();
	}
	
	if($_(".smartbutton").length > 0){
		$_('.smartbutton').fadeOut();
	}
}

// PopUp for Chat Now
function openPopUp(isEnable, accountId, departmentId, loc) {
	//console.log($_(this).attr('id'));
 var loc = loc || "";
	if(isEnable)
	centeredWin('https://ems02051.egain.net/system/web/view/live/templates/chevrolet_desktop_chat/chat.html?entryPointId=1001', 'Chat', '550','375', 'yes', 'no', 'no', 'no', 'no', 'no', 'no');
    else
        centeredWin(BASE_CONTEXT + '/pages/misc/chat/popup.do', 'Chat', '400','300', 'yes', 'no', 'no', 'no', 'no', 'no', 'no');
    var divisionObj = DIVISION.toUpperCase();
    clickTrack({pageName: divisionObj+' | '+s.prop3+' | CHAT NOW | LAUNCH',
        prop1: '',
        prop2: '',
        prop3: '',
        prop4: '',
        prop5: '', 
        prop6: '',
        prop7: '',
        prop9: '',
        prop10: '',
        prop11: 'CHAT NOW | '+s.prop3+' | '+loc+' | LAUNCH',
        prop12: 'CHAT',
        prop17:'',
        prop18:'',
		//changed line below
		//was
        //prop24:'', prop25:divisionObj,
		//now  separated prop24 prop25
		prop24:'',
		prop25:'CHEVROLET',
        prop26:'',
        prop27: ''});
    return true;
}

function flashChatCheckIt(){
    var totalParams = "";
    if(isChatReadyOn){
        totalParams = "true, '";
    } else{
        totalParams = "false, '";
        flashStatus = 1
    }
     totalParams += paramsToAdd + "'"
    if(null != thisMovie("flashObj_nav") && undefined != thisMovie("flashObj_nav")){
        thisMovie("flashObj_nav").changeChatState(flashStatus, "openPopUp", totalParams);
    }
}