/* Kelley Blue Book widget functions */

(function($){
  if ($_('div.kbbWidget').length == 0) {
    $_(document).ready(function() {
	  
 	  /* Dynamically replace label text in feed based on match */
	  $_('.kbb_column2 dl dt').each(function() {
		if ($_.trim($_(this).text()) == 'Overall Rating') 	{ $_(this).text('Overall Consumer Rating'); }
		if ($_.trim($_(this).text()) == 'Performance') 		{ $_(this).text('Driving'); }
		if ($_.trim($_(this).text()) == 'Styling') 			{ $_(this).text('Design'); }
	  });
	  
	  /* Pull out 'Overall Rating' from first element to rearrange layout */
	  $_('.kbbWidget').each(function() {
		$_(this).find('.kbbrating_container span').replaceWith($_(this).find('.kbb_ratings_1 .stars-dialog').text());
		$_(this).find('div.kbb_column1 div.kbbtitle span').replaceWith($_(this).find('.kbb_ratings_1 dt').text());
		$_(this).find('.kbb_ratings_1').css({'display':'none'});
		/*$_(this).find('.kbb_column2 .kbb_title a span').replaceWith('<img src="../assets/en/images/model/overview/common/kbb_ratings/kbb_title.png" alt="Kelley Blue Book Consumer Reviews" />');*/
		$_(this).find('.kbb_column2 .kbb_title a span').replaceWith('<span class="kbb_title_text"></span>');
	  });
	  
	  /* ie7 css fixes */
	  if ($_.browser.msie  && parseInt($_.browser.version) == 7) {
		$_('.kbb_rating').css({'margin':'3px 0 0 24px'});
		
		$_('.kbb_title_img').css({'margin':'10px 0 0 0px'});
		$_('.kbbrating_container').css({'margin':'3px 0 0 0px'});
		
	  }
	  
    });
  }
}(mrm.$));