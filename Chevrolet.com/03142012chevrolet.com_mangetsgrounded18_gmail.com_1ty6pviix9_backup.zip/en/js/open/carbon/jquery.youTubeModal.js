(function($){
	$.fn.extend({
		youTubeModal: function( options ) {
			var defaults = {
				autohide       : 1,
				autoplay       : 1,
				height         : 385,
				modestbranding : 1,
				width          : 638,
				wmode          : 'transparent'
			}
			var options =  $.extend(defaults, options);
			return this.each( function(){
				var $this = $( this ),
					add = "";
				$this.videoLocation = $this.attr( 'href' );
				$this.videoId = /v=([A-Za-z0-9_-]*)\&?/.exec( $this.videoLocation )[1];
				$( '<div class="youTubeModal"><div class="youTubeVid"></div><div class="close">[X] close</div>').prependTo( 'body' );
				$( '.youTubeModal .youTubeVid' ).mrmplayer({
					playerType:'youtube',
					vidID          : $this.videoId,
					width          : options.width,
					height         : options.height,
					autoHide       : options.autoHide,
					autoStart      : options.autoplay,
					modestBranding : options.modestbranding,
					wmode          : options.wmode
				});

				$( '.youTubeModal .close' ).click( function() { $( '.youTubeModal' ).remove();});
				$( '<div class="offClickYouTube"></div>' ).prependTo( '.hotspotWrap' ).click( function(){ $( '.youTubeModal .close' ).click(); $( this ).remove() });
			});
		}
	});
})(jQuery);