window.addEvent('domready', initAccordion);
var myAccordion;

function initAccordion() {
	//create our Accordion instance
	myAccordion = new Accordion($('accordion-faq'), 'li.togglerFaq', 'li.elementFaq', {
		opacity: false,
		alwaysHide:true,
		show:(document.location.href.indexOf("/experience/")>-1)? -1 : 0,
		onActive: function(toggler, element){
			toggler.removeClass('togglerFaq');
			toggler.addClass('selected');
		},
		onBackground: function(toggler, element){
			toggler.removeClass('selected');
			toggler.addClass('togglerFaq');
		}
	});
	
}

function changeSectionFaq(section){
	var specificSection="menu_"+ section;
	$_("#menu_section1").addClass("active");
	$_("#sections li a").removeClass("active");
	$_("#menu_" + section).addClass("active");
	$_("#accordion-faq div").each(function(){
		if($_(this).hasClass("sectionBlock"))
			$_(this).removeClass("sectionBlock").addClass("sectionHidden");
	});
	$_("#"+section).addClass("sectionBlock");
	
	// Get first item of current FAQ section
	var firstElement = $_("#" + section).find("li.elementFaq").first().attr("id");
	var sectionIndex = Number(firstElement.replace("elementFaq", ""))-1;
	myAccordion.display(sectionIndex);
}

function init() {
	try{
		document.getElementById("menu_section1").className = "active";
	} catch(e) {
		
	}
	
}
function myGeneric() {
	alert('hi');
}
function trackingFAQS(name){
	var divisionObj = BRAND.toUpperCase();
	var nameObj = unescape(name.toUpperCase());
	clickTrack({pageName: divisionObj+' | DIVISIONAL | HELP CENTER | FAQ', prop1: 'DIVISIONAL', prop2:'HELP CENTER', prop3: 'DIVISIONAL | HELP CENTER', prop4: 'FAQ', prop5:'HELP CENTER | FAQ', prop6: 'DIVISIONAL | HELP CENTER | FAQ', prop7:nameObj, prop8: 'FAQ | '+nameObj, prop9: 'HELP CENTER | FAQ | '+nameObj, prop10: 'DIVISIONAL | HELP CENTER | FAQ | '+nameObj,prop11:'INDEX',prop12:nameObj+' | INDEX',prop13:'FAQ | '+nameObj+' | INDEX',prop14:'HELP CENTER | FAQ | '+nameObj+' | INDEX',prop15:'DIVISIONAL | HELP CENTER | FAQ | '+nameObj+' | INDEX',prop17:'LEARN MORE',prop18:'RESEARCH',prop24:'EN', prop25:divisionObj, prop26:(new Date()).getHours(), prop27: weekday[(new Date()).getDay()]});
}
function trackingQuestion(name,question){
	var divisionObj = BRAND.toUpperCase();
	var nameObj = unescape(name.toUpperCase());
	var questionObj = replaceApostropheCode(unescape(question.toUpperCase()));
	clickTrack({pageName: divisionObj+' | DIVISIONAL | HELP CENTER | FAQ', prop1: 'DIVISIONAL', prop2:'HELP CENTER', prop3: 'DIVISIONAL | HELP CENTER', prop4: 'FAQ', prop5:'HELP CENTER | FAQ', prop6: 'DIVISIONAL | HELP CENTER | FAQ', prop7:nameObj, prop8: 'FAQ | '+nameObj, prop9: 'HELP CENTER | FAQ | '+nameObj, prop10: 'DIVISIONAL | HELP CENTER | FAQ | '+nameObj,prop11:questionObj,prop12:nameObj+' | '+questionObj,prop13:'FAQ | '+nameObj+' | '+questionObj,prop14:'HELP CENTER | FAQ | '+nameObj+' | '+questionObj,prop15:'DIVISIONAL | HELP CENTER | FAQ | '+nameObj+' | '+questionObj,prop17:'LEARN MORE',prop18:'RESEARCH',prop24:'EN', prop25:divisionObj, prop26:(new Date()).getHours(), prop27: weekday[(new Date()).getDay()]});
}



function replaceApostropheCode(value) {
	value = value.replace('&APOS;', '\'');
	value =  value.replace('&#39;', '\'');
	return value;
}


AttachEvent(window, "load", init);