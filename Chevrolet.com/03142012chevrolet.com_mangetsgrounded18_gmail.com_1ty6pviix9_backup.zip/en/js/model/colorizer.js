/* 
 * Colorizer
 * Version: 0.9.0
 * Package: app.colorizer
 * Requires: jQuery 1.4.1 
 * Author(s): Jesse Atkinson (DET-MRM)
 * Notes: This app is intended to control the hero (masthead background) image's
 * color and angle. The user should be able to jump between various colors 
 * while retaining which angle they are on. 
 * 
 * The angle is controlled with a basic previous/next functionality while the
 * color is changed by jumping between gallery instances. For every color there is
 * is an entire new gallery. The unique identifier on the gallery is an ID of
 * #heroHEXVALUE where HEXVALUE is the color's hex code. For example: the ID on 
 * a car's white gallery would be #heroffffff. 
 * 
 * We use the colorChange() function to show and hide the galleries and seamlessly
 * transition between them using a combination of .fadeIn, .fadeOut, and .delay.
 * 
 * There will also need to be error catching added it. In a perfect world we 
 * will always have the same amount of images for each color, but error catching
 * should be added just in case we don't. If proper error catching is implemented
 * this will allow for more portable an recyclable code. 
 * 
 * All vehicle images are located in your assets branch at 
 * ~/assets/en/images/model/2012/VEHICLE/overview/masthead
 */
var _current = 0,
	_currentMastheadVideoId,
	_firstRunMuted = false;

var app = app || {};
app._safeToChangeColor = true;


(function ($) { /* Closure that allows you to use $ instead of $_ for jQuery on Chevy.com. */
    $.extend(app, {
        angleCount: 0,
        firstRun: true,
		logging : true,
        colorizer: {
			config : {
				callback : false,
				secondary : false,
				secondaryTooltip : false,
				fadeTime : 500,
				firstRunMuted : false
			},
            color: $("#colorizer dd a").first().attr("rel"),
            init: function (settings) {
            	var self = this;
				for (var i in settings) {
					this.config[i] = settings[i];
				}
				self.events();
				
				// launch full screen video if required
				
				if (this.config.brightcoveId) {
					_currentMastheadVideoId = this.config.brightcoveId;
					if (!$('body').hasClass('m_ios')) {
						$('#mastheadVideo').show();
						self.initVideo(self.config.brightcoveId);
					} else {
						//$('#mastheadVideo').hide();
					}					
				}
				
				$("div#hero div.hero.activeHero").show();
            },
            colorChange: function () {
                var angleIndex = $("div.activeHero").data("mrmgallery").currentSlideIndex();
                var _oldactive = $("div.activeHero");
                var _newactive = $("div.hero" + this.color);
                if (_oldactive[0] !== _newactive[0]) {
                    app._safeToChangeColor = false;
                    _newactive.addClass("activeHero");
                    _oldactive.removeClass("activeHero");
                    _oldactive.css({
                        'z-index': 5
                    });

                    _newactive.css({
                        'z-index': 10
                    });
                    
                    if (_newactive.data("mrmgallery") == null) {
                    	this.initGallery(_newactive, angleIndex);
                    } else {
                    	// Need to manually set class and display setting, otherwise MRM Gallery will not change slides correctly
                    	_newactive.children().eq(angleIndex).addClass('activeitem').css('display','block');
                    	_newactive.data("mrmgallery").goToSlide(angleIndex, false);
                    }
                   
                    _newactive.fadeTo(500, 1, function () {
                        _oldactive.fadeTo(300, 0, function () {
							if (app.colorizer.config.callback) {
								var oldColor = _oldactive.find('img')[0].getAttribute('alt');
								var newColor = _newactive.find('img')[0].getAttribute('alt');

								app.colorizer.imageSwap(oldColor, newColor);
							}
							app._safeToChangeColor = true;
                        });
                    });

                    this.activeKeyboard(_newactive);

                    app.dotGallery();
                    if (app.firstRun == true) {
                        app.firstRun = false;
                    }
                }

            },
            initGallery:function(jqObj, angleIndex) {
            	jqObj.mrmgallery({
            		slideIndex : angleIndex,
					easing          : "linear",
					crossFade       : true,
					enableShare     : true,
					enableKeyboard  : true,
					slideComplete   : function( slideIndex ){
						_current=slideIndex;
												 
						// check for the type undefined, because we have one offs that
						// do use this top but not the colorizer						
						if (typeof app != 'undefined')
						{					
							app.dotGallery();
							app._safeToChangeColor = true;
						}
					},
					transitionSpeed : 900
				});
            },            
            activeKeyboard: function (_activeHero) {
                // handle keyboard events
                _activeHero.siblings(".mrmgallery").each(function () {
                    $(this).data("mrmgallery").disableKeyboard(1);
                });
                if (_activeHero.data("mrmgallery") != null)
                	_activeHero.data("mrmgallery").disableKeyboard(0);
            },
            events: function () {
            	var self = this;
                $(window).resize(function () {
                    var windowWidth = $(window).width();
                    var nextArrowWidth = $('div.mrmgallery-arrow.next').width();
                    var prevArrowWidth = $('div.mrmgallery-arrow.prev').width();
                    var heroWidth = $('#hero').width();
                    var heroCoverWidth = $('#heroHover').width();

                    if (windowWidth < 1280) $('#hero').width(windowWidth);
                    else $('#hero').width(1280);

                    if (windowWidth < 980 + nextArrowWidth + nextArrowWidth) {
                        $('#heroHover').width(windowWidth - nextArrowWidth - nextArrowWidth);
                        $('#heroHover').css('margin-left', -((windowWidth - nextArrowWidth - nextArrowWidth) / 2) + 'px');
                    } else {
                        $('#heroHover').width(980);
                        $('#heroHover').css('margin-left', '-490px');
                    }
                });

                $("dl#colorizerShare dd a.downloadBtn").live("click", {
                    namespace: this
                }, function (e) {
                    var imageSrc = $("div.activeHero div.activeitem img").attr("longdesc");
                    fireInterstitial('/pages/misc/instersticial/popupToExteriorLink.do?newURL=' + imageSrc);
                });

                $("dl#colorizer dd a").live("click", {
                    namespace: this
                }, function (e) {
                    e.preventDefault();
                    if (app._safeToChangeColor) {
                        var ns = e.data.namespace;
                        var thisActiveColor = $(this).parent().parent().attr("class");
                        var thisNewColor = $(this).attr('rel');
                        var angleIndex = _current = $("div.activeHero").data("mrmgallery").currentSlideIndex();
                        if (thisActiveColor != "colorChip activeColor") {
							ns.config.callback ? clearTimeout(ns.config.timer) : $.noop();
                            $('dl#colorizer dd').removeClass("activeColor");
                            $('div#vehicleCaptions div').removeClass('activeText');
                            $('div#vehicleCaptions div.'+thisNewColor).addClass('activeText');
                            ns.color = $(this).attr("rel");
                            ns.colorChange();
                        }
                        if (navigator.platform == 'iPad') {
                            $("span", this).hide();
                        }
                    }

                });

                $("dl#colorizer dd a").hover(function () {
                    if (navigator.platform == 'iPad') {
                        return;
                    }
                    var desc = $(this).attr("name");

                    if ($("span", this).length <= 0) {
                        $(this).append("<span><img src='../assets/en/images/model/overview/common/tooltip_caret_up.png' alt='Arrow' />" + desc + "</span>");
                        $("span", this).css({
                            "left": -($("span", this).width() / 2) + "px",
                            "width": (desc.length * 6) + "px"
                        });
                    } else {
                        $("span", this).show();
                    }
                }, function () {
                    $(".colorChip a span").hide();
                });

                // masthead video close button
                $('#mastheadVideoClose').live("click", function(e) {
                	e.preventDefault();
                	video.pause();
                	app.colorizer.toggleVideo('hide');
                });
                // change all other slides too
                $(".activehero div.mrmgallery-arrow a").live("click", function () {
                    var currentIndex = $("div.activeHero").data("mrmgallery").currentSlideIndex();
                    $("div.hero.mrmgallery").children().removeClass("activeitem");

                    $("div.hero.mrmgallery").not("div.activeHero").each(function () {
                        $(this).children().eq(currentIndex).addClass("activeitem");
                    });
                    var currentColor = $("div.activeHero div.activeitem img").attr("alt").toUpperCase().replace(/_/g, " ");
                    app.log("color should be" + currentColor);
                    if ($(this).parent().hasClass("prev")) {
                        var arrowDirection = "ARROW LEFT";
                    } else {
                        var arrowDirection = "ARROW RIGHT";
                    }
                    s.prop2 = "MODEL HOMEPAGE";
                    s.prop3 = s.prop1 + " | " + s.prop2;
                    s.prop4 = "MASTHEAD";
                    s.prop5 = s.prop2 + " | " + s.prop4;
                    s.prop6 = s.prop3 + " | " + s.prop4;
                    s.prop7 = "SEE360";
                    s.prop8 = s.prop4 + " | " + s.prop7;
                    s.prop9 = s.prop2 + " | " + s.prop4 + " | " + s.prop7;
                    s.prop10 = s.prop3 + " | " + s.prop4 + " | " + s.prop7;
                    s.prop11 = arrowDirection;
                    s.prop12 = s.prop7 + " | " + s.prop11;
                    s.prop13 = s.prop8 + " | " + s.prop11;
                    s.prop14 = s.prop2 + " | " + s.prop13;
                    s.prop15 = s.prop1 + " | " + s.prop14;
                    s.prop17 = "NEED-TO-KNOW";
                    s.prop18 = "RESEARCH";
                    s.prop20 = s.prop15 + " | " + arrowDirection;
                    s.prop40 = "VEHICLE EXPLORATION";
                    s.eVar40 = "RESEARCH";
                    s.manageVars("clearVars", "prop51,prop52,prop53,prop54,prop61,eVar44,eVar45,eVar57,eVar58", 1);
                    s.t();
                });
				
				if (this.config.secondary) {
					$('.secondaryColorizer').live('click', function () {
						var color = $(this).find('img').attr('src').split('icon_')[1].split(/\.(jpg|png)/)[0];
						$('#colorizer a[rel="' + color + '"]').click();
					});
					if (this.config.secondaryTooltip){
						$('body').append('<div class="secondaryTooltip" />');
						$('.secondaryColorizer').bind('mouseenter',function (){
							var tooltext = $(this).find('img').attr('alt');
							var toolOffset = $(this).offset();
							var iconWidth = this.offsetWidth;
							var iconHeight = this.offsetHeight;
							$('.secondaryTooltip').show().html(tooltext).css({
								top: toolOffset.top + iconHeight,
								left: toolOffset.left + (iconWidth - $('.secondaryTooltip').outerWidth()) / 2
							});
					
						}).bind('mouseleave',function(){
							$('.secondaryTooltip').hide();
						});
					}
				}
				$('#videoReplay').live('click', function() {
					 self.config.firstRunMuted = false;
					 $('#mastheadVideo').show(function() {
						 $(this).fadeTo(1000, 1, function() {app.colorizer.toggleVideo('show');});
					 });
				});
            },
			imageSwap : function (oldColor, newColor) {
				var images = $('.swapable').find('img'),
					newImage;

				for (var i = 0, len = images.length; i < len; i++) {
					if (~images[i].src.indexOf(oldColor)) {
						app.colorizer.scopeListener(images[i], oldColor, newColor);
					}
				}
			},
			scopeListener : function (oldImage, oldColor, newColor) {
				var newImage = new Image(),
					newElem = $(newImage),
					oldElem = $(oldImage);
				
				newElem.load(function () {
					newElem.hide().css({
						position : 'absolute',
						zIndex : 2
					});
					oldElem.css('zIndex', 1);
					oldElem.parent().prepend(newElem);
					newElem.fadeIn(app.colorizer.config.fadeTime, function () {
						oldElem.remove();
					});
				});
				
				newImage.src = oldImage.src.replace(oldColor, newColor);
			},
			initVideo: function(brightcoveId) {
				// create the video layer
				_currentMastheadVideoId = brightcoveId;		
				_firstRunMuted = this.config.firstRunMuted;
				// create the video
				var mastheadVideo = $('#mastheadVideo');
				mastheadVideo.addClass('background').fadeTo(0,1);
				mastheadVideo.mrmplayer({
						vidID: brightcoveId,
						playerKey:'AQ~~,AAAAABQIifY~,yBcYMa-7eoJgoOGVYPXg1RwwKHr35oxe',
						width: 1280,
						height: 600,
						enableFullBCAPI:true,
						defaultBGColor:'#000000',
						bcTemplateLoadHandler: 'colorizerBCEvents'
				});
				
				$('#mastheadVideoClose').show();
				
			},
			toggleVideo: function(toggle) {
		    	if (toggle === 'show') {  
		    		$('#mastheadVideo').show(function() {
		    			$(this).fadeTo(1000, 1, 'swing', function() {
		    				app.colorizer.initVideo(app.colorizer.config.brightcoveId);});
		    				$('#mastheadVideoClose').show();
		    			});
		    		
		    	} else if (toggle === 'hide') {
		    		$('#mastheadVideo').fadeTo(1000, 0, 'swing', function() {
		    			$_(this).hide();
		    		});   
		    		$('#mastheadVideoClose').hide();
		    	}
		    } 
        },
        dotGallery: function () {
            if (app.angleCount > 1) {
                $("ul.galdots").children("li").remove();
                for (slideCount = 0; slideCount < app.angleCount; slideCount++) {
                    var isCurrent = (slideCount == _current) ? 'current' : '';
                    $("ul.galdots").append("<li class='" + isCurrent + " ' id='dots'>&bull; </li>");
                }
                $("ul.galdots li").click(function () {
                    $("div.activeHero").data("mrmgallery").goToSlide($(this).index(), true);
                    var currentIndex = $("div.activeHero").data("mrmgallery").currentSlideIndex();
                    $("div.hero.mrmgallery").children().removeClass("activeitem");
                    $("div.hero.mrmgallery").not("div.activeHero").each(function () {
                        $(this).children().eq(currentIndex).addClass("activeitem");
                        $(this).children().eq(currentIndex).css("display", "");
                    });
                });
            }
        },
		log : function (message) {
			if (this.logging && typeof console !== 'undefined') {
				console.log(message);
			}
		}
    });
}($_));

var video, player, modVP, modExp;
//BC Flash Javascript API events - Big Browser
function onTemplateLoaded (id) {
	var isMasthead = ('myExperience'+_currentMastheadVideoId == id);
	if (isMasthead) {		
	    player = bcPlayer.getPlayer(id);
	    video = player.getModule(APIModules.VIDEO_PLAYER);
	    video.addEventListener(BCMediaEvent.BEGIN, bcBegin);
	    video.addEventListener(BCMediaEvent.PROGRESS, bcProgress);
	    video.addEventListener(BCMediaEvent.COMPLETE, bcComplete);
	    $_('#videoReplay').bind('click', function () {	
		   	 video.removeEventListener(BCMediaEvent.COMPLETE);
		   	 video.addEventListener(BCMediaEvent.COMPLETE, bcComplete);
		});
	}
}
//BC SmartPlayer API events iPad
function colorizerBCEvents(experienceID) {
		var isMasthead = ('myExperience'+_currentMastheadVideoId == experienceID);
		if (isMasthead) {				
			player = brightcove.api.getExperience(experienceID);
			video = player.getModule(brightcove.api.modules.APIModules.VIDEO_PLAYER);
		    modExp = player.getModule(brightcove.api.modules.APIModules.EXPERIENCE);
		    modExp.addEventListener(brightcove.api.events.ExperienceEvent.TEMPLATE_READY, function() {
		    	 video.addEventListener(brightcove.api.events.MediaEvent.BEGIN, bcBegin);
		    	 video.addEventListener(brightcove.api.events.MediaEvent.PROGRESS, bcProgress);
		    	 video.addEventListener(brightcove.api.events.MediaEvent.COMPLETE, bcComplete);
		    });
		    $_('#videoReplay').bind('click', function () {	
		   	 video.removeEventListener(brightcove.api.events.MediaEvent.COMPLETE);
		   	 video.addEventListener(brightcove.api.events.MediaEvent.COMPLETE, function () {app.colorizer.toggleVideo('hide');});
		   });
		}
}
function bcBegin(evt) {
	if (_firstRunMuted)
		video.setVolume(0);
	else
		video.setVolume(1);
	selection: "MASTHEAD REPLAY",
	mrm.cmp.omniture.trackChevy({selection: "MASTHEAD VIDEO BEGIN"});
}
function bcComplete(evt) {
	console.log('complete');
	_firstRunMuted = false;
	app.colorizer.toggleVideo('hide');
	try {$_('#mastheadVideo').data("mrmplayer").destroy();} catch(e){}
	mrm.cmp.omniture.trackChevy({selection: "MASTHEAD VIDEO COMPLETE"});	
	
}
function bcProgress(evt) {
	if (evt.position > evt.duration - .1) {
		app.colorizer.toggleVideo('hide');
	}
}