/*Chris's Code - Not Touching */
//*******************************************************************************************************************************************
//*******************************************************************************************************************************************
//** This file handles the Omniture tracking for the Model Overview Page.  
//** NOTE:  The mrmGallery dots (bullets under the galleries on the model overview page) can be found in en\pages\model\overview\full2012.jsp
//**  		for the full-sized gallery or en\pages\model\imageLayout2012.jsp for the smallery half-sized gallery.  
//*******************************************************************************************************************************************
//*******************************************************************************************************************************************
var _firstclicktrack = true;

function modelOverviewTracking(placement){
//alert('id: ' + id + ', placement: ' + placement + ', order: ' + order);
      var trackingObj = {
	  	/*pageName: 'CHEVROLET | HHR | MODEL OVERVIEW | INDEX | DEFAULT',
	  	prop1: 'HHR',
	  	prop2: 'MODEL OVERVIEW',
	  	prop3: 'HHR | MODEL OVERVIEW',
	  	prop4: 'INDEX',
	  	prop5: 'MODEL OVERVIEW | INDEX',
	  	prop6: 'HHR | MODEL OVERVIEW | INDEX',
	  	prop7: 'INDEX',
	  	prop8: 'INDEX | DEFAULT',
	  	prop9: 'MODEL OVERVIEW | INDEX | DEFAULT',
	  	prop10: 'HHR | MODEL OVERVIEW | INDEX | DEFAULT',
	  	prop11: 'CHEVROLET | HHR | MODEL OVERVIEW | INDEX | DEFAULT',
		prop12: 'testing',
	  	prop19: 'CAR',
	  	prop24: 'EN',
	  	prop25: 'GM',
		prop26: getESTHour(),
		prop27: daysofweek[(new Date()).getDay()].toUpperCase()*/
		prop20: 'CHEVROLET | HHR | MODEL OVERVIEW | ' + placement
	  };                                   
      clickTrack(trackingObj);
}

/*
$_(document).ready(function() {
   $_('#modulesLeft a').click(function() {
   	//alert("calling oTracking function");
   	oTracking('o','LEFT','1','','static'); //or '_blank'
	});
	$_('#modulesTop a').click(function() {
	  	modelOverviewTracking('TOP');
	});
	$_('#modulesMain a').click(function() {
	  	modelOverviewTracking('MAIN');
	});
	$_('#modulesBottom a').click(function() {
	  	modelOverviewTracking('BOTTOM');
	});
});*/

/* -------------------------------
	trackPromoAppEmailSignup - fires tracking event
	bThankYou 	- true ==> fires on the thank-you redirect
	 			- false ==>  fires on the submit click
------------------------------- */
function trackPromoAppEmailSignup(bThankYou)
{
	var selection = "E-MAIL SIGNUP";
	if (bThankYou)
		selection += " THANK YOU";
	// omniture tracking
	mrm.cmp.omniture.trackChevy({ selection: selection});	
	// dart tracking
	try {
	mrm.cmp.dart.fire('spt_' + _year + _brand + '_promoApp');
	} catch(e) {}
}

function createModelTrackingBinds()
{
	/* -------------------------------
	 Promo app submit button click
	 ------------------------------- */
	$_('form#helpCenterRequestForm input#submit').live('click', function()
	{
		trackPromoAppEmailSignup(false);		
	});
	
	/* -------------------------------
		 Download Bind
		 ------------------------------- */
	//This function reports the tracking for the live click on the Model Overview Page for the social share options.		 
	$_('div.mg_share div.mg_socialshare div.mg_buttons div.mg_socialbutton').live('click', function()
	{
		//Identify which share option is being selected.
		var _socialshare = '';
			if ($_(this).hasClass('mg_facebook')) {_socialshare='FACEBOOK';}
			if ($_(this).hasClass('mg_twitter')) {_socialshare='TWITTER';}
			if ($_(this).hasClass('mg_download')) {_socialshare='DOWNLOAD';}

		//Get the section name.
		var _section = $_(this).parents('div.moduleContainer').attr('id').toUpperCase().split('_')[0].split('-')[0];
		
		//Get the image name.
		var _image = $_(this).parents('div.dynamic-gallery.mrmgallery').find('div.galleryItem.activeitem').find('span.social span.share-thumbnail').text();
				
		var _temp = _image.split('/');
			_image	= _temp[_temp.length - 1];
			_image	= _image.toUpperCase().split('.')[0];
		var _imageNumber = [_image.slice(- 2)];
		
		if (_socialshare=='DOWNLOAD')
			{ s.prop20 = ""; }
		else
		{
			_image = "SHARING";
			_imageNumber = _socialshare;
		}
		s.prop17 = "VEHICLE EXPLORATION";
		s.prop18 = "RESEARCH";
		mrm.cmp.omniture.trackChevy({ siteSection: 'MODEL HOMEPAGE', selection: _image, subSelection: _imageNumber, activeState: _section});
			

	});
	//Tracking for Back to top links on the model overview page - Competitive Compare Section.
	$_('div.moduleWrapper div.backTop a').live('click', function()
	{
		var _modButton = $_(this).text().toUpperCase().split('_')[0];
		
		var _section = $_(this).parents('div.moduleWrapper').find('div.moduleContainer').attr('id').toUpperCase().split('_')[0];
		// console.log(_section);
		s.prop17 = "VEHICLE EXPLORATION";
		s.prop18 = "RESEARCH";
		mrm.cmp.omniture.trackChevy({ siteSection: 'MODEL HOMEPAGE', selection: _modButton, activeState: _section});
		
	});

	
	//This function reports	the tracking for the live click on the color chips for the Model Overview Page on the masthead.
	$_('div#colorizerWrapper dl#colorizer dd.colorChip div.outline a').live('click', function()
	{
		var _color = $_(this).attr('name').toUpperCase().split('_')[0];
			s.prop17 = "NEED-TO-KNOW";
			s.prop18 = "RESEARCH";
		mrm.cmp.omniture.trackChevy({ siteSection: 'MODEL HOMEPAGE', selection: 'SEECOLORS', subSelection: _color, activeState: 'MASTHEAD'});

		if (_firstclicktrack == true)
		{
			// Spotlight Tracking
			var _brand 	= s.prop1.split(/\W/).join('').toLowerCase();
			var _year 	= s.prop23;
			mrm.cmp.dart.fire('spt_' + _year + _brand + '_colorswatch');
			_firstclicktrack = false;
		}
	});
	
	// Video Replay Buttons
	$_('#videoReplay').live('click', function() {		
		mrm.cmp.omniture.trackChevy({selection: "MASTHEAD REPLAY"});	
	});
	
	//This function will handle arrow clicks on the Colorizer for Spotlight Tracking
	$_(	'div#hero div.mrmgallery div.mrmgallery-arrow,'
		 +'div#dotgalnav ul.galdots li').live('click', function()
	{
		// Spotlight Tracking
		var _brand 	= s.prop1.split(/\W/).join('').toLowerCase();
		var _year 	= s.prop23;
		mrm.cmp.dart.fire('spt_' + _year + _brand + '_colorarrow');
		
		// Only fire once
		$_('div#hero div.mrmgallery div.mrmgallery-arrow,div#dotgalnav ul.galdots li').die('click');
	});
	
	
	//This function will report the tracking for the share menu button options next to the color swatch on the masthead section of the Model Overview Page.
	$_('div#colorizerWrapper dl.shareMenu dd a').live('click', function()
	{
		var _socialshare = '';
		
		if ($_(this).hasClass('facebookBtn')) {_socialshare='FACEBOOK';}
		if ($_(this).hasClass('twitterBtn')) {_socialshare='TWITTER';}
		if ($_(this).hasClass('downloadBtn')) {_socialshare='DOWNLOAD';}

			s.prop17 = "NEED-TO-KNOW";
			s.prop18 = "RESEARCH";
		mrm.cmp.omniture.trackChevy({ siteSection: 'MODEL HOMEPAGE', selection: 'SHARING', subSelection: _socialshare, activeState: 'MASTHEAD'});
	});

	//This reports the tracking for the module buttons.
	$_('div.afterModuleButtons a').live('click', function()
	{              
		var _modButton = $_(this).text().toUpperCase().split('_')[0];
		_modButton = $.trim(_modButton);

		if (_modButton != "SEE FULL COMPARISON")
		{
				var _section = $_(this).parents('div.moduleWrapper').find('div.moduleContainer').attr('id').toUpperCase().split('_')[0];
		} else {
				var _section = "COMPETITIVE COMPARISON";
		}
			s.prop17 = "VEHICLE EXPLORATION";
			s.prop18 = "RESEARCH";
		mrm.cmp.omniture.trackChevy({ siteSection: 'MODEL HOMEPAGE', selection: _modButton, activeState: _section});
	});	


//MASTHEAD/TOP
	//Top Links - BYO
	$_('a.byoButtonTop').live('click',function(e) {
		e.stopPropagation();
		e.stopImmediatePropagation();	
		var selection = $_(this).attr('class').toUpperCase().split('_')[0];
		mrm.cmp.omniture.trackChevy({ siteSection: 'MODEL HOMEPAGE', selection: selection, activeState: 'TOP CTAS'});
	});
	//Top Links - Downloads
	$_('div.downloadLink a').click(function(e) {
		e.stopPropagation();
		e.stopImmediatePropagation();	
		var selection = $_(this).html().toUpperCase().split('_')[0];
		mrm.cmp.omniture.trackChevy({ siteSection: 'MODEL HOMEPAGE', selection: selection, activeState: 'DOWNLOADS'});
	});
	//Top Links - Anchor Text
	$_('#introNav li a').click(function() {
		var selection = $_(this).html().toUpperCase().split('_')[0];
		mrm.cmp.omniture.trackChevy({ siteSection: 'MODEL HOMEPAGE', selection: selection, activeState: 'ANCHOR TEXT'});
	});
	
	//Tracking promotiles to the right of the introduction on the model overview page.
	$_('div#intro div#introRight div#mastheadPromos a img').click(function() {
		var _selection = $_(this).attr('id').toUpperCase().split('_')[0];

		// console.log(_selection);
		if (_selection == "WARRANTY")
		{
			_pwrtrn = "POWERTRAIN";
			_selection = _pwrtrn;	
		}
		if (_selection == "CURRENT OFFER")
		{
			_offers = "VIEW CURRENT OFFERS";
			_selection = _offers;	
		}		
		mrm.cmp.omniture.trackChevy({ siteSection: 'MODEL HOMEPAGE', selection: _selection, activeState: 'TOP PROMO TILES'});
	});
	
	//Shopping Bar Tracking (also referred to as the Resource Bar)

	//MAIN STORIES - Links
	
	//MAIN STORIES
	//InStory - Links	
$_('#modulesMain a').live('click',function(e) {
	//Exclude the Footer Stuff
	//var bottom = $_(this).parentsUntil('div.moduleContainer').parent().attr('id').split('_')[0];
	var bottom = $_(this).parentsUntil('.moduleWrapper').parent().children('.moduleContainer').attr('id').toUpperCase().split('_')[0];
	if (bottom == "bottom") {
	}
	else if( bottom == "atagSpecialOffers") {
	}
	else if( bottom == "kbb") {
	}
	else {
	
		//CHANGE THE SELECTION FOR EXCEPTIONS - SHARE AND IMAGE FLIPPER
		var thisclass = $_(this).attr('class');	
		if (thisclass == "showShareOptionsBtn selected")
			{		var selection = "SHARE"; }
		else if (thisclass == "facebookBtn")
			{	 var selection = "SHARE";	}
		else if (thisclass == "twitterBtn")
			{	var selection = "SHARE"; }
		else if (thisclass == "emailBtn")
			{	var selection = "SHARE"; }
		else 
			{	var selection = $_(this).html(); }
		//SET THESE FOR ALL LINKS ON PAGE
			//console.log(selection);
					
		//var section = $_(this).parents('.moduleContainer').attr('id').toUpperCase().split('_')[0];
		var section = $_(this).parentsUntil('.moduleWrapper').parent().children('.moduleContainer').attr('id').toUpperCase().split('_')[0];
		if (section.length <= 0) 
			{ section = "MHP_CLICK";	}
		
		var _subselect = '';
		if (thisclass == "facebookBtn") 
			{	_subselect = 'FACEBOOK'; }
		else if (thisclass == "twitterBtn")
			{	_subselect = 'TWITTER'; }
		else if (thisclass == "emailBtn")
			{	_subselect = 'EMAIL'; }
		else if (thisclass == "forward")
		{
			var imgnum_init = $_(this).parent().find('.current').next();
			if (imgnum_init.length <= 0)
				{ _subselect = $_(this).parent().find('.current').parent().find('a:first').attr('href').split("tab")[1]; }
			else 
				{ _subselect = imgnum_init.attr('href').split("tab")[1]; }
		}			
		else if (thisclass == "backward")
		{
			var imgnum_init = $_(this).parent().find('.current').prev();
			if (imgnum_init.length <= 0)
				{ _subselect = $_(this).parent().find('.current').parent().find('a:last').attr('href').split("tab")[1]; }
			else 
				{ _subselect = imgnum_init.attr('href').split("tab")[1]; }
		}			
		else if (thisclass == "flipper")
			{ _subselect = $_(this).attr('href').split("tab")[1];	}
		else if (thisclass == "flipper current")
			{ _subselect = $_(this).attr('href').split("tab")[1];	 }
		
		selection = selection.toUpperCase();
		if ((!$_(this).parents('ul').hasClass('dot_nav')) && (!$_(this).parents('div').hasClass('mrmgallery-arrow'))) {
			mrm.cmp.omniture.trackChevy({ siteSection: 'MODEL HOMEPAGE', selection: selection, subSelection: _subselect, activeState: section});
		}
		}

});
	//InStory - KBB
	$_('#modulesMain #kbb a').click(function(e) {
		e.stopPropagation();
		e.stopImmediatePropagation();
		mrm.cmp.omniture.trackChevy({ siteSection: 'MODEL HOMEPAGE', selection: "VIEW REVIEWS", activeState: 'KBB'});
	});
	

//BOTTOM
	//Bottom Links CTA
	$_('#vehicleSynopsisLinks a').click(function(e) {
		e.stopPropagation();
		e.stopImmediatePropagation();
		var selection = $_(this).html().toUpperCase().split('_')[0];
		mrm.cmp.omniture.trackChevy({ siteSection: 'MODEL HOMEPAGE', selection: selection, activeState: 'BOTTOM CTAS'});
	});
	//Bottom Links - BYO
	$_('a.byoButtonBottom').click(function(e) {
		e.stopPropagation();
		e.stopImmediatePropagation();
		var selection = $_(this).attr('class').toUpperCase().split('_')[0];
		mrm.cmp.omniture.trackChevy({ siteSection: 'MODEL HOMEPAGE', selection: selection, activeState: 'BOTTOM CTAS'});
	});
	//Bottom Promos
	$_('div.highlightPromo').click(function() {
		//// console.log("test");
		var selection = $_(this).parent().attr('id').toUpperCase().split('_')[0];
		mrm.cmp.omniture.trackChevy({ siteSection: 'MODEL HOMEPAGE', selection: selection, activeState: 'BOTTOM PROMO TILES'});
	});
}	


$_(document).ready(function() 
{
	// create aht tracking event binds
	createModelTrackingBinds();
	
	// get the variables of the page attached to the url
	var vars = [], hash;
	var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
	for(var i = 0; i < hashes.length; i++)
	{
		hash = hashes[i].split('=');
		vars.push(hash[0]);
		vars[hash[0]] = hash[1];
	}   
	
	// check if this is a thank you page redirect from the emial signup submit promo app
	if (vars['thankyou'] != undefined)
	{
		trackPromoAppEmailSignup(true);
	}
});