var _TOUCHES_ = {};
var overview={
	loadPlugin : function() {
		$_.getScript(BASE_CONTEXT + "/mds/js/plugins/jquery.home.min.js", function(){
			jQuery(".slidetabs").tabs(".images > div", {
				effect: 'fade',
				fadeInSpeed: "200",
				fadeOutSpeed: "200",
				history: true,
				rotate: true
			}).slideshow();
		});
	}
}

var overlay = { //overlay box launched from intro module
	init : function(div) {
		var self = this;
		/*if(navigator.userAgent.match(/iPad/i)) {
			$_(div).css({
				position: 'absolute',
				top: $_(window).scrollTop()
			});
		} else {
			$_(div).css({position: ('fixed')});
		}*/
		$_(div).css({position: ('fixed')});
		self.positionOverlayBox(div);
			
		$_('#overlay').css({display: ('block')});
		$_(div).css({display: ('block')});
		// ajax specific loads
		var useAjax = false;
		var ajaxURL = '';
		var selectorToLoad = '';
		switch (div) {
			case '#overlayBoxVoltFAQ':
				ajaxURL = '/en/pages/model/2012/volt/overview/includes/voltFAQ.jsp';
				selectorToLoad = 'div#overlayBoxVoltFAQ';
				break;
		}
		//$_(selectorToLoad).html('loading...');
		$_.ajax({
			  url: ajaxURL,
			  success: function(data){
				  $_(selectorToLoad).append(data);
					self.positionOverlayBox(div);
			  },
			  cache:true
			});
	},
	cancel : function(div) {
		$_('#overlay').css({display: ('none')});
		$_(div).css({display: ('none')});
	},
	positionOverlayBox : function(div) {
		//position overlay divs and center box
		$_(div).insertBefore($_("#gMdsPage"));
				
		var wrapperWidth = parseInt($_(window).width());
		var lbWidth = parseInt($_(div).width());
		var leftOverArea = wrapperWidth - lbWidth;
		var lbLeftOffset = (leftOverArea/2);
		$_(div).css({left: lbLeftOffset+"px"});
		
		//volt FAQ overlay
		if (($_("body").hasClass("volt")) && ($_(div).attr("id") == "overlayBoxVoltFAQ")) {
			var y = $_(div).offset().top;
			var topMargin = parseInt(y) + 50;
			
			$_(div).css({position: ('absolute')});
			$_(div).css({marginTop: (topMargin)});
			if($_.browser.msie){
				if($_.browser.version < 8)$_(div).css({overflow: ('auto')});
			}
		} else {
			$_(window).scroll(function (event) {
				if(navigator.userAgent.match(/iPad/i)) {
					$_(div).css({
						position: 'absolute',
						top: $_(window).scrollTop()
					});
				} else {
					$_(div).css({position: ('fixed')});
				}
				if($_.browser.msie){
					if($_.browser.version < 8)$_(div).css({overflow: ('auto')});
				}
			});
		}
	},
	submitVoltDealerForm : function(e, txtFieldVal) {	
		var evt, keycode;
		
		evt = e || window.event;
  		keycode = evt.which || evt.keyCode;
		
		if (keycode == 13 || e.type == "click") { //enter button pressed or 'Go' button clicked
		   	var zipValid = validateZip(txtFieldVal);
			if(zipValid) location.href="/tools/dealerlocator/result.do?BRANDID=ch&desiredCount=25&searchType=ByPostalCode&searchByPostalCodeProximity=500&dealerType=VSO&searchByPostalCodePostalCode="+txtFieldVal;
			return (keycode != 13);			
		}
	},
	submitVoltEmailForm : function(e, txtFieldVal) {
		var evt, keycode;
		
		evt = e || window.event;
  		keycode = evt.which || evt.keyCode;
				
		if (keycode == 13 || e.type == "click") {//enter button pressed or 'Sign Up' button clicked
		   	callEmailForm('Volt', txtFieldVal);
			return (keycode != 13);
		}
	}
}

var video={
	show : function() {
		$_('#mastheadLbBtn').click();
	}
}

/*function setWidth(){
	$_("#gMdsPage").width($_(window).width());
}
$_(window).resize(function() {
	if($_(window).width() <= 1280) {
         setWidth();            
    } else {
		$_("#gMdsPage").css({width: (1280+"px")});
	}
});*/

var lightbox={ //lightboxes launched from main modules
	centerLB : function() {
		//calculate lightbox left offset
		var wrapperWidth = parseInt($_(window).width());
		var lbWidth = parseInt($_("#sb-wrapper").width());	
		var leftOverArea = wrapperWidth - lbWidth;
		var lbLeftOffset = (leftOverArea/2);
		

		$_("#sb-wrapper").css({left: lbLeftOffset+"px"});
		
	},	
	updateLB : function(media) {
		lbWrapper = $_("#sb-wrapper-inner");
		switch(media){
			case "brightcove":
				lbWrapper.removeClass("lbPromo");
				lbWrapper.removeClass("lbImage");
				lbWrapper.addClass("lbBrightcove");
				break;
			case "promo":
				lbWrapper.removeClass("lbBrightcove");
				lbWrapper.removeClass("lbImage");
				lbWrapper.addClass("lbPromo");
				break;
			default:
				lbWrapper.removeClass("lbBrightcove");
				lbWrapper.removeClass("lbPromo");
				lbWrapper.addClass("lbImage");
				break;
		}
		
		setTimeout('lightbox.centerLB()', 500);
	},
	currentPlayId : 0,
	closeLayer : function(uid){
		this.bcExperienceModule.unload();
		$_('#sb-container').hide();
		lightbox.currentPlayId = 0;
	},
	showLayer : function(id,width,height,uid) {
	
		if(lightbox.currentPlayId!=0){
			return false;
		}

		lightbox.currentPlayId=uid+'-'+id;
		$_('#sb-container').remove();

		var htmlStr = '<div id="sb-container" style="display: block; visibility: visible; height: 297px; width: 1423px; ">'
					+'<div id="sb-overlay" style="background-color: rgb(0, 0, 0); opacity: 0.5; "></div>'
					+'<div id="sb-wrapper" style="visibility: visible;width:1002px;">'
					+'<div id="sb-title">'
					+'<div id="sb-title-inner" style="margin-top: 0px; "></div>'
					+'</div>'
					+'<div id="sb-wrapper-inner" style="height: 235px; " class="lbBrightcove">'
					+'<div id="sb-body">'
					+'<div id="sb-body-inner">'
					+'<div id="sb-player" class="html">'
					+'<div id="'+uid+'-'+id+'">'
					+'<div class="inner-lb-content">'
					+'	<a onclick="lightbox.closeLayer(\''+uid+'-'+id+'\');" title="Close" class="sb-nav-close" style="display:block;">'
					+'		<img src="'+BASE_CONTEXT+'/assets/en/images/global/lightbox/close.gif" />'
					+'	</a>'
					+'	<div class="lbWrapper">'
					+'		<object id="myExperience'+id+'" class="BrightcoveExperience">'
					+'			<param name="bgcolor" value="#FFFFFF" />'
					+'			<param name="width" value="'+width+'" />'
					+'			<param name="height" value="'+height+'" />'
					+'			<param name="playerID" value="90402351001" /'
					+'			<param name="publisherID" value="336103926"/>'
					+'			<param name="isVid" value="true" />'
					+'			<param name="isUI" value="true" />'
					+'			<param name="dynamicStreaming" value="true" />'
					+'			<param name="@videoPlayer" value="'+id+'" />'
					+'			<param name="templateLoadHandler" value="lightbox.videoTemplateLoaded" />'
					+'		</object>'
					+'	</div>'
					+'</div></div></div></div></div></div></div></div>';
					
			$_('body').prepend(htmlStr);

            // hide until container centers
            $("#sb-wrapper").hide();

			brightcove.createExperiences(); 				
	
			if(mrm.util.iOS()) {
				$_("#sb-overlay").remove();				
				var re = new RegExp(/CPU OS ([0-9_]+) like Mac OS X/);
				var appleVersion = re.exec(navigator.appVersion);
				var majorAppleVersion = 0;
				if (appleVersion != null) {
					majorAppleVersion = parseInt(appleVersion[1].split('_'));
				}
				if (majorAppleVersion < 5){
					var currentY = $_("body").scrollTop()+"px";
					$_('#sb-wrapper-inner').css(
							{"position":"absolute",
							 "margin-top": currentY
							 
							}); 					
					var lbOffset = 1002/2;
					$_("#sb-wrapper").css({left:'50%', marginLeft:(-lbOffset)+'px'});
				} else {
					setTimeout('lightbox.centerLB()', 500);
				}
			} else {
				setTimeout('lightbox.centerLB()', 500);
			}
			$_('div#sb-overlay').hide();

                        //wait for container to center
                       setTimeout(function(){$_("#sb-wrapper").show()},500);
	},
	setLBPaths : function(startingId, lbImgPaths, lbMediaType) {
		//console.log(startingId + ", " + lbImgPaths + ", " + lbMediaType);
		
		var arrImgPaths = lbImgPaths.split(',');
		
		for(var i=0;i<arrImgPaths.length;i++) {
			assetDiv = "#"+startingId+(i+1)+" .inner-lb-content .lbWrapper";
			
			if(lbMediaType == "brightcove") {
				//$_(assetDiv).html("<object id='myExperience"+arrImgPaths[i]+"' class='BrightcoveExperience'><param name='bgcolor' value='#FFFFFF' /><param name='width' value='940' /><param name='height' value='529' /><param name='playerID' value='90402351001' /><param name='publisherID' value='336103926'/><param name='isVid' value='true' /><param name='isUI' value='true' /><param name='dynamicStreaming' value='true' /><param name='@videoPlayer' value='"+arrImgPaths[i]+"' /></object>");
				//$_(assetDiv).html("<object height='529' width='940' type='application/x-shockwave-flash' data='http://c.brightcove.com/services/viewer/federated_f9?&width=940&height=529&flashID=myExperience"+arrImgPaths[i]+"&bgcolor=%23FFFFFF&playerID=90402351001&publisherID=336103926&isVid=true&isUI=true&dynamicStreaming=true&%40videoPlayer="+arrImgPaths[i]+"&autoStart=' id='myExperience"+arrImgPaths[i]+"' class='BrightcoveExperience'><param name='allowScriptAccess' value='always'><param name='allowFullScreen' value='true'><param name='seamlessTabbing' value='false'><param name='swliveconnect' value='true'><param name='wmode' value='window'><param name='quality' value='high'><param name='bgcolor' value='#FFFFFF'></object>");
			} else {
				//image gallery
				$_(assetDiv).html("<img src='"+arrImgPaths[i]+"' />");
			}	
		}
	},
	bcPlayer : null,
	bcExperienceModule : null,
	videoTemplateLoaded : function(brightcoveId) {
		this.bcPlayer = brightcove.getExperience(brightcoveId);
		// get references to the experience and video player modules
		this.bcExperienceModule = this.bcPlayer.getModule(APIModules.EXPERIENCE);
	}
}

$_(document).ready(function(){
	
	/*
	$_(".moduleContainer").mouseenter(function(){
		if($_(this).attr("id") != ""){
			console.log($_(this).attr("id"))
		}
	})*/

	
	$_("#overlay").insertBefore($_("#gMdsPage"));
	
	//intro and bottom modules - arrow animations
	/*$_(".promoCaption").mouseover(function(){
		$_("img", this).animate({
			marginLeft: '3px'
		}, 100, function(){
		});
	});
	$_(".promoCaption").mouseout(function(){
		$_("img", this).animate({
			marginLeft: '0px'
		}, 100, function(){
		});
	});*/
	
	//yahoo auto reviews - arrow animations
	/*$_(".reviewBtmLink").mouseover(function(){
		$_("img:nth-child(2)", this).animate({
			marginLeft: '3px'
		}, 100, function(){
		});
	});
	$_(".reviewBtmLink").mouseout(function(){
		$_("img:nth-child(2)", this).animate({
			marginLeft: '0px'
		}, 100, function(){
		});
	});*/
	
	//lightbox overlay - arrow animations
	$_(".arrLeft").mouseover(function(){
		$_(this).attr({
			src: "../assets/en/images/global/lightbox/left_arrow_over.png"
		});
	});
	$_(".arrLeft").mouseout(function(){
		$_(this).attr({
			src: "../assets/en/images/global/lightbox/left_arrow.png"
		});
	});
	$_(".arrRight").mouseover(function(){
		$_(this).attr({
			src: "../assets/en/images/global/lightbox/right_arrow_over.png"
		});
	});
	$_(".arrRight").mouseout(function(){
		$_(this).attr({
			src: "../assets/en/images/global/lightbox/right_arrow.png"
		});
	});
	
	$_(".highlightPromo").mouseover(function(){
		$_(this).animate({
			opacity: '.4'
		}, 100, function(){
		});
		$_(this).animate({
			opacity: '0'
		}, 300, function(){
		});
	});
	
	/*$_(".mastheadPromo").mouseover(function(){
		var arrow = $_(this).find(".mastheadPromoArrow");
		var arrowLeftMargin = arrow.css('marginLeft').split('px');
		arrowLeftMargin = parseInt(arrowLeftMargin[0]) + 3;
		arrowLeftMargin = arrowLeftMargin.toString() + "px";
		
		//arrow.css({backgroundPosition: '0 -120px'});
		
		arrow.stop().animate({
			marginLeft: arrowLeftMargin,
		}, 100, function(){
		});
	});
	$_(".mastheadPromo").mouseout(function(){
		var arrow = $_(this).find(".mastheadPromoArrow");
		var arrowLeftMargin = arrow.css('marginLeft').split('px');
		arrowLeftMargin = parseInt(arrowLeftMargin[0]) - 3;
		arrowLeftMargin = arrowLeftMargin.toString() + "px";
		
		//arrow.css({backgroundPosition: '0 -100px'});
		
		arrow.stop().animate({
			marginLeft: arrowLeftMargin
		}, 100, function(){
		});
	});*/
	
	/*$_('#mastheadLbBtn').click(function(){
		lightbox.updateLB('brightcove');
	});*/
	
	//fix lightbox 'nested copy div' issue when image appears left of copy
	if ($_(".copyMedium")) {
		$_(".copyMedium").each(function(){
			if ($_(this).parent().hasClass("imageMedium")) {
				$_(this).insertAfter($_(this).parent());
			}
		});
	}
	
	//set divider height
	//var modulesTopHeight = $_('#modulesTop').height();
	//var modulesMainHeight = $_('#modulesMain').height();
	//var mainAreaHeight = modulesTopHeight + modulesMainHeight;
	
	//$_("#lineWrapper").css({visibility: 'visible', height: (mainAreaHeight)});
	
	$_('.showMoreLink').click(function(){
		var parentDiv = $_(this).parent().find("div");
		if (parentDiv.hasClass("showMoreCopy")) {
			parentDiv.toggle();
		}
		
		if($_(this).hasClass('showMoreLink')) {
			$_(this).removeClass('showMoreLink').addClass('showMoreLinkActive');
		} else {
			$_(this).removeClass('showMoreLinkActive').addClass('showMoreLink');
		}
	});
	
	//if ($_(".slidetabs")) {
//		$_(".content-gallery").each(function(){
//			var pictureWidth=0;
//			var pictureHeight=0;
//			var marginLeft=[], marginRight=[];
//			
//			$_(this).("img.longdesc").each(function(){				
//			var	currentpictureWidth = parseInt($_(this).width());
//			var	currentpictureHeight = parseInt($_(this).height());
//				
//				slidetabsWidth+=currentDotWidth;
//			});
//			
//			//set width of slidetab controls so they will center properly
//			$_(".content-gallery").css({width: (currentpictureWidth.toString()+'px')});
//			$_(".dynamic-gallery").css({width: (currentpictureWidth.toString()+'px')});
//			$_(".content-gallery").css({height: (currentpictureHeight.toString()+'px')});
//			$_(".dynamic-gallery").css({height: (currentpictureHeight.toString()+'px')});
//		});
	//}
	
	setTimeout("overview.loadPlugin()", 3000); //this needs a delay or Volt FAQ popup does not work in IE7
	
	
	//moduleScroller.data("slideshow").play();
	
	
	$_('a.forward').click(function(){
		try{
		$_(".slidetabs").data("slideshow").stop();
		} catch(err){}
	});
	
	$_('a.backward').click(function(){
		try{
		$_(".slidetabs").data("slideshow").stop();
		} catch(err){}
	});
	
	//set download link widths dynamically, so they won't push the other links to the right on bold mouseover
	$_(".downloadLink a").each(function(){
		curDownloadLinkWidth = $_(this).width();
		curDownloadLinkWidth = curDownloadLinkWidth + 30;
		$_(this).css('width',curDownloadLinkWidth+"px");
	});
	
	// heroHover
	$_("#heroHover").hover(
	function(){
		$_('div#hero div.mrmgallery-arrow').show().fadeTo(200, 1);
	});
	
	// share
	$_(".imageWrapper").hover(
		function(){
			//$_(this).children(".shareMenu").css('display','block');
			$_(this).children(".shareMenu").fadeIn('fast');
		},
		function(){
			$_(this).children(".shareMenu").children(".top").fadeOut('fast');
			$_(this).children(".shareMenu").fadeOut('fast');
			
			$_(this).find(".showShareOptionsBtn").removeClass("selected");
		}
	);
	
	$_(".showShareOptionsBtn").click(
		function(){
			
			//$_(this).parent().parent().find(".facebookBtn").fadeIn(400);
			//$_(this).parent().parent().find(".twitterBtn").delay(200).fadeIn(400);
			//$_(this).parent().parent().find(".emailBtn").delay(400).fadeIn(400);
			
			$_(this).parent().parent().parent().children(".top").fadeIn('fast');
			$_(this).addClass("selected");
		}
	);
	
	$_(".emailBtn").click(
		function(){
			// handle email
		
			var shareTitle = $_(this).parent().parent().parent().children(".share-title").text();
			var shareDescription = $_(this).parent().parent().parent().children(".share-description").text();
			var atag = $_(this).parent().parent().parent().children(".share-atag").text();
			
			// link
			var host = window.location.host;
			var protocol = window.location.protocol;
			var pathname = window.location.pathname;
			var shareURL = protocol + '//' + host + pathname; // + "?atag=" + atag;
			var disclaimer = "This email does not add the sender's or recipient's email address to the Chevrolet marketing email list. However, if you provided us your email address, or we received it through some other source, we may use it in accordance with our privacy statement at http://www.gm.com/privacy ."
			
			
			var shareSubject = shareTitle;
			var shareMessage = shareDescription + "\n\n" + shareURL + "\n\n" + disclaimer;
			
			MRMSocial.email(shareSubject,shareMessage);
		}
	);
	
	//allow client-requested 'second brightcove thumbnail' under Volt Performance to work
	//if ($_("body").hasClass("volt")) {
		$_("#performance2 .lightboxImageLink").clone().insertAfter("#performance .lightboxImageLink");
		$_("#performance2").css("display","none");
	//}
		/* FAQ accordion */
		$_('div#accordion-faq li.togglerFaq').live('click', function() {
			$_(this).addClass('selected').removeClass('.togglerFaq');
			$_(this).next('li.elementFaq').css({'height':'', 'display':''});
		});
		$_('div#accordion-faq li.selected').live('click', function() {
			$_(this).addClass('togglerFaq').removeClass('selected');
			$_(this).next('li.elementFaq').css({'height':'0px', 'display': 'none'});
		});
		
		
 /* Mobile captures */
    if (_ISMOBILE_) {
    	mrm.mob.touch.swipeLeft("#heroHover", function() {
    		if ($_("div.activeHero").data("mrmgallery") != null) {
    			$_("div.activeHero").data("mrmgallery").slide('next');
    		}
    	});
    	mrm.mob.touch.swipeRight("#heroHover", function() {
    		if ($_("div.activeHero").data("mrmgallery") != null) {
    			$_("div.activeHero").data("mrmgallery").slide('prev');
    		}
    	});
    }
});

function voltTrackingFAQS(name){
	var divisionObj = BRAND.toUpperCase();
	var nameObj = unescape(name.toUpperCase());
	clickTrack({pageName: divisionObj+' | DIVISIONAL | HELP CENTER | FAQ', prop1: 'DIVISIONAL', prop2:'HELP CENTER', prop3: 'DIVISIONAL | HELP CENTER', prop4: 'FAQ', prop5:'HELP CENTER | FAQ', prop6: 'DIVISIONAL | HELP CENTER | FAQ', prop7:nameObj, prop8: 'FAQ | '+nameObj, prop9: 'HELP CENTER | FAQ | '+nameObj, prop10: 'DIVISIONAL | HELP CENTER | FAQ | '+nameObj,prop11:'INDEX',prop12:nameObj+' | INDEX',prop13:'FAQ | '+nameObj+' | INDEX',prop14:'HELP CENTER | FAQ | '+nameObj+' | INDEX',prop15:'DIVISIONAL | HELP CENTER | FAQ | '+nameObj+' | INDEX',prop17:'LEARN MORE',prop18:'RESEARCH',prop24:'EN', prop25:divisionObj, prop26:(new Date()).getHours(), prop27: weekday[(new Date()).getDay()]});
}
function voltTrackingQuestion(name,question){
	var divisionObj = BRAND.toUpperCase();
	var nameObj = unescape(name.toUpperCase());
	var questionObj = replaceApostropheCode(unescape(question.toUpperCase()));
	clickTrack({pageName: divisionObj+' | DIVISIONAL | HELP CENTER | FAQ', prop1: 'DIVISIONAL', prop2:'HELP CENTER', prop3: 'DIVISIONAL | HELP CENTER', prop4: 'FAQ', prop5:'HELP CENTER | FAQ', prop6: 'DIVISIONAL | HELP CENTER | FAQ', prop7:nameObj, prop8: 'FAQ | '+nameObj, prop9: 'HELP CENTER | FAQ | '+nameObj, prop10: 'DIVISIONAL | HELP CENTER | FAQ | '+nameObj,prop11:questionObj,prop12:nameObj+' | '+questionObj,prop13:'FAQ | '+nameObj+' | '+questionObj,prop14:'HELP CENTER | FAQ | '+nameObj+' | '+questionObj,prop15:'DIVISIONAL | HELP CENTER | FAQ | '+nameObj+' | '+questionObj,prop17:'LEARN MORE',prop18:'RESEARCH',prop24:'EN', prop25:divisionObj, prop26:(new Date()).getHours(), prop27: weekday[(new Date()).getDay()]});
}

function goTo(url){
	if (url.indexOf("http")>-1) {
		var target="_blank";
	}else{
		var target="_self";
	}
	window.open(url, target);
}

function onDotClick(atag,index) {
	var api = $(atag + " .slidetabs").data("tabs");
	api.click(index)
}

function doBYOspecial(oRef){
	if ( oRef == undefined ) oRef = this;
    	validateCookie(oRef,'specialBYO()','byo',false,'');
        //posZipAfterDo(oRef);
        return false;
}
function specialBYO(){
	var postalCode = zipDialogLocation.zipcode;
	location.href=BASE_CONTEXT+'/tools/byo/byoCustomizeVehicle.do?year=2011&brand=equinox&title=&region=&evar10=byo_path_buildbytrim&pvc=10015&optionList=PDK';
}
function shareFBContentWell(atag) {
	var shareMessage = "";
	var activeItem = $_("div#hero div.activeHero div.activeitem");	
	var shareCaption = activeItem.children(".share-caption").text();
	var shareThumbnail = activeItem.children('img').attr("longdesc");
	var shareTitle = document.title;
	var shareDescription = $_("head meta[name=DESCRIPTION]").attr('content');
	// link
	var host = window.location.host;
	var protocol = window.location.protocol;
	var pathname = window.location.pathname;
	var shareURL = protocol + '//' + host + pathname;// + "?atag=" + atag;
	//thumb url
	shareThumbnail = protocol + '//' + host + shareThumbnail;
	MRMSocial.fbPublishGalleryItem(shareMessage,shareTitle,shareCaption,shareDescription,shareThumbnail,shareURL);
}
function tweetPage(atag) {	
	// link
	var host = window.location.host;
	var protocol = window.location.protocol;
	var pathname = window.location.pathname;
	var shareURL = protocol + '//' + host + pathname;	
	MRMSocial.tweet(shareURL,'');
}

// override to turn off CSS3 mrmgallery transitions
_TRANSLATE3D_ = false;