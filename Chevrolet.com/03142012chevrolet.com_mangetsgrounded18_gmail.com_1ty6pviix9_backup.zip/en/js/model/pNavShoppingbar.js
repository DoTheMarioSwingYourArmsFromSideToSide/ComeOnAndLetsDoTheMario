var _onshopnav = 0;
var _onshopbar = 0;
var isipad = navigator.platform == 'iPad' || navigator.platform == 'iPhone' || navigator.platform == 'iPod';

var _shoppingnav = {
  	
	// Assign the events
	_events: function () 
	{
		$_("div.nsb_tools:not(.subactive)").live(isipad ? 'click' : 'mouseenter', function () { 
			if (isipad) $_("div.nsb_tools.subactive").trigger("click");
			$_(this).addClass('subactive');
			$_('#' + this.id + ' ul.nsb_popmenumain li ul.nsb_popmenu').stop().slideDown(function(){$_(this).css("height", "auto")});
	  		_onshopnav = 1;
  			var relName = $_(this).attr('rel');
				s.prop40 = "NEED-TO-KNOW";
				s.prop41 = "RESEARCH";
				s.manageVars("clearVars","eVar9,prop11,prop12,prop13,prop14,prop15,prop20",1);
				mrm.cmp.omniture.trackChevy({ siteSection: 'MODEL HOMEPAGE', selection: 'EXPAND MENU', activeState: relName});
  		});
		$_("div.nsb_tools.subactive").live(isipad ? 'click' : 'mouseleave', function () { 
			$_(this).removeClass('subactive');
			$_('#' + this.id + ' ul.nsb_popmenumain li ul.nsb_popmenu').stop().slideUp(function(){$_(this).css("height", "auto")});
	  		_onshopnav = 0;
		});

		$_('div#nsb_shtools ul.nsb_popmenumain li ul.nsb_popmenu li.nsb_li a').live('click', function() {
			if ($_(this).prop('rel')=="scroll") {
			  	if(isipad) { 
				  $_("div.nsb_wrapper_border1").hide(); 
				  $_("div#nsb_shtools ul.nsb_popmenumain li ul.nsb_popmenu").hide(); 
				}
				$_.scrollTo( $_('div'+$_(this).attr('href')), 800, {
				  axis:'y',
				  onAfter:function(){ if(isipad) { $_(window).triggerHandler('scroll'); } } 
				});
			}
			var tabClick = $_(this).children("div").html().toUpperCase();
			mrm.cmp.omniture.trackChevy({ siteSection: 'MODEL HOMEPAGE', selection: tabClick, activeState: 'SHOPPING TOOLS'});
		});	

		$_('div#nsb_onpage ul.nsb_popmenumain li ul.nsb_popmenu li.nsb_li a').live('click', function() {
			if ($_(this).prop('rel')=="scroll") {
			  	if(isipad) { 
				  $_("div.nsb_wrapper_border1").hide(); 
				  $_("div#nsb_onpage ul.nsb_popmenumain li ul.nsb_popmenu").hide(); 
				}
				$_.scrollTo( $_('div'+$_(this).attr('href')), 800, {
				  axis:'y',
				  onAfter:function(){ if(isipad) { $_(window).triggerHandler('scroll'); $_("div.nsb_wrapper_border1").show(); } } 
				});
			}
			var tabClick = $_(this).children("div").html().toUpperCase();
			s.manageVars("clearVars","eVar9,prop11,prop12,prop13,prop14,prop15,prop20",1);
			mrm.cmp.omniture.trackChevy({ siteSection: 'MODEL HOMEPAGE', selection: tabClick, activeState: 'ON THIS PAGE'});
				
		});	

		$_('div#nsb_chat div.nsb_title').live('click', function() {
			mrm.cmp.omniture.trackChevy({ siteSection: 'MODEL HOMEPAGE', selection: 'LAUNCH', activeState: 'CHAT'});
		});	
		
	},
	// Initialize the Toolbar
	_init: function () 
	{
		// Position the "On this page" bar
		var _position  	= $_("div#nsb_onpage").offset();
		var _titlewidth	= $_("div#nsb_onpage").width();
		var _menuwidth	= $_("div#nsbotp_nav").width();
		var _posmodifier = (_titlewidth - _menuwidth)
		var _height = $_('div#nsbotp_nav').height();
		
		if (_posmodifier < 0) {_posmodifier = (_posmodifier * -1);}
		$_('div#nsbotp_nav').css({ left:(Math.round(_position.left) -  _posmodifier + 2 ), bottom:(_height * -1)} );


		// Position the "Shopping Tools" bar
		var _position  = $_("div#nsb_shtools").offset();
		var _titlewidth	= $_("div#nsb_shtools").width();
		var _menuwidth	= $_("div#nsbst_nav").width();
		var _posmodifier = (_titlewidth - _menuwidth)
		var _position  = $_("div#nsb_shtools").offset();
		var _height = $_('div#nsbst_nav').height();

		if (_posmodifier < 0) {_posmodifier = (_posmodifier * -1);}
		$_('div#nsbst_nav').css({ left:_position.left, bottom:(_height * -1)} );
			
		this._events();
		
		// Fixed position hack for iPad (won't be needed as of iOS 5)
		if (isipad) {
		  $_("div.nsb_wrapper_border1").appendTo("body");
		  var shoppingBar = $_("div.nsb_wrapper_border1");
		  $_("div.nsb_wrapper_border2").hide();
		  var shoppingBarHeight = 33;
		  shoppingBar.css({
		    "position": "absolute",
		    "top": "auto",
		    "bottom": "auto"
		  });
		  function repositionShoppingBar() {
		    shoppingBar.css("bottom", ($_(document).height() - window.pageYOffset - window.innerHeight) + 'px').show();
		  }
		  $_("<div style='clear:both'></div>").appendTo("#gMdsFooter div.hook"); // Fix this in html later
		  $_(window).bind('touchmove', function(e){shoppingBar.hide();});
		  $_(window).bind('touchend', repositionShoppingBar);
		  $_(window).bind('scroll', repositionShoppingBar);
		  //repositionShoppingBar();
		  setTimeout ( repositionShoppingBar, 6000 ); 
		  	// Reposition in case iPad autoscrolled to previous position (only on reload)
		}
	}
}

var resourceBar = {
	loadCount: 0,
	nineTwelve: 1280,
	init: function(){
		if ($_(window).width() < 1280) {
			this.nineTwelve = 980;
		}
		var nineTwelve = this.nineTwelve;
		this.sizeBar(nineTwelve);
		this.listenForResize();
	},
	sizeBar: function(barSize){
		$_('.nsb_container').removeClass('nsb_container_1280');
		$_('.nsb_wrapper_border1').removeClass('nsb_wrapper_border1_1280');
		$_('.nsb_wrapper_border1').removeClass('nsb_wrapper_border1_980');
		$_('.nsb_wrapper_border1').addClass('nsb_wrapper_border1_'+barSize);
		this.loadCount++;
		this.nineTwelve = barSize;
		this.bottom();
	},
	listenForResize: function(){
		$_(window).resize(function(){
			var winRes = $_(window).width();
			if (winRes >= 1280) {
				resourceBar.sizeBar(1280);
			} else {
				resourceBar.sizeBar(980);
			}
		});
	},
	bottom: function(){
		var nineTwelve = this.nineTwelve, timeOutAnim, mouseInBar = false;
		$_('.nsb_container').addClass('nsb_container_'+nineTwelve);
		$_('.nsb_wrapper_border2').css('bottom','auto');
		$_('.nsb_wrapper_border1').mouseenter(function(){
			mouseInBar = true;
		}).mouseleave(function(){
			mouseInBar = false;
		});
		function hideResourceBar(){
			$_('.nsb_wrapper_border1').animate({bottom:-120},{queue:false,duration:400});
		}
		function showResourceBar(){
			$_('.nsb_wrapper_border1').show().animate({bottom:0},{queue:false,duration:400});
		}
		if (this.loadCount === 1) {
			hideResourceBar();
			timeOutAnim = setTimeout(showResourceBar,2000);
		}
		$_(window).scroll(function(){
			if (mouseInBar === false) {
				clearTimeout(timeOutAnim);
				hideResourceBar();
				timeOutAnim = setTimeout(showResourceBar,1000);
			}
		});
	}
};

$_(document).ready(function(){
	
	if ($_('.nsb_container').length) {
		if (!isipad) {
			resourceBar.init();
			_shoppingnav._init();
		} else {
			$_('.nsb_container').hide();
		}
	}
});