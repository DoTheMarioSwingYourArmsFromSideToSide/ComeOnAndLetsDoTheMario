$_(document).ready(function(){
	// New method to replace fonts
	Cufon.set('fontFamily', 'Klavika CH Medium');
	Cufon.replace(".f_klavmed");

	if (typeof(MSRP_COLOR)!="undefined") { // MSRP_COLOR gets written to the page in the JSP
		
		Cufon.replace(".klavCHMed", {
			fontFamily: 'Klavika CH Medium'
		});
		
		Cufon.replace(".mastheadMSRPDollarSign", {
			fontFamily: 'Klavika CH Medium',
			fontSize: '26px',
			color: MSRP_COLOR
		});
		
		Cufon.replace(".mastheadDollarSign", {
			fontFamily: 'Klavika CH Medium',
			fontSize: '30px',
			color: MSRP_COLOR
		});
		
		Cufon.replace(".mastheadMSRP", {
			fontFamily: 'Klavika CH Medium',
			fontSize: '50px',
			color: MSRP_COLOR
		});
		
		Cufon.replace(".mastheadPrice", {
			fontFamily: 'Klavika CH Medium',
			fontSize: '46px',
			color: MSRP_COLOR
		});
	}
	
	Cufon.replace("h2.vehOptHeadingSml", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '18px',
		color: '#ffffff'
	});
	
	Cufon.replace("h2.vehOptHeadingLrg", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '23px',
		color: '#ffffff'
	});
	
	Cufon.replace(".msrpDollarSign", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '14px',
		color: '#000000'
	});
	
	Cufon.replace(".msrpHeading", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '30px',
		color: '#000000'
	});
	
	Cufon.replace(".msrpLabel", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '24px',
		color: '#ffffff'
	});
	
	Cufon.replace(".choice", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '16px',
		color: '#ffffff'
	});
	
	Cufon.replace(".listLink", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '12px',
		color: '#2385B2'		
	});
	
	Cufon.replace(".moduleHeadingMedium", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '19px',
		color: '#616161'
	});
	
	Cufon.replace(".moduleHeadingMediumWhite", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '19px',
		color: '#ffffff'
	});
	
	
	Cufon.replace(".tileHeading", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '15px',
		color: '#333'
	});
	
	
	Cufon.replace(".vehName", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '42px',
		color: '#fff'
	});
	
	
	/*Cufon.replace(".introModuleHeading", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '32px',
		color: '#4e4f50'
	});*/
	
	Cufon.replace(".MASTHEADSUP", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '19px',
		color: '#4e4f50'
	});
	
	/*Cufon.replace(".mainModuleHeading", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '27px',
		color: '#4e4f50'	
	});*/
	
	Cufon.replace(".mainModuleSubHeading", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '15px',
		color: '#616161'
	});
	
	Cufon.replace(".configTitle", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '17px',
		color: '#ffffff'
	});
	
	// Cufon for the Features & Specs Tab Menu (configTabs & activeTab)
	/*
	Cufon.replace(".configTabs", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '15px',
		color: '#ffffff'
	});
	
	Cufon.replace(".activeTab", {
		hover: true,
		fontFamily: 'Klavika CH Medium',
		fontSize: '15px',
		color: '#6e9eb2'
	});
	*/
	
	/*Cufon.replace(".moduleHeading", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '15px',
		color: '#616161'		
	});*/
	
	Cufon.replace(".moduleHeadingSml", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '10px',
		color: '#9B9B9B'		
	});
	
	Cufon.replace(".onstarPromoHeading", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '14px',
		color: '#5e6261'	
	});
	
	Cufon.replace(".vehSynopsisPromoHeading", {
		fontFamily: 'Klavika CH Medium',
		fontSize: '15px',
		color: '#616161'
	});
	/* -----------------------------------
	// -- Font - Klavika Medium Condensed
	// ----------------------------------- */
	Cufon.replace(".f_klavchmedcon", { fontFamily: 'Klavika CH Medium Condensed'	});
	Cufon.replace(".f_klavchmed", { fontFamily: 'Klavika CH Medium'	});
});